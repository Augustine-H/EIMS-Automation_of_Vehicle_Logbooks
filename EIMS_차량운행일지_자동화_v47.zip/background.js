
'use strict';

const STATE_KEY = 'eimsVehicleLogExtensionStateV7';

async function getState() {
  const got = await chrome.storage.local.get(STATE_KEY);
  return got[STATE_KEY] || {};
}

async function setState(s) {
  await chrome.storage.local.set({[STATE_KEY]: s});
}

async function refreshEpoch(reason) {
  const self = await chrome.management.getSelf();
  const prev = await getState();
  const now = Date.now();
  const version = chrome.runtime.getManifest().version;

  let epoch = prev.epoch || `${now}-${crypto.randomUUID()}`;

  // New install/reinstall: local storage is empty -> new epoch.
  // New version: manifest version differs -> new epoch.
  // Re-enable: prior persisted state says disabled -> new epoch.
  if (!prev.version || prev.version !== version || prev.enabled === false || reason === 'installed') {
    epoch = `${now}-${crypto.randomUUID()}`;
  }

  const next = {
    epoch,
    version,
    enabled: self.enabled !== false,
    updatedAt: now
  };
  await setState(next);
  return next;
}

chrome.runtime.onInstalled.addListener(async details => {
  try {
    // install and update both invalidate "오늘 하루 그만보기".
    const self = await chrome.management.getSelf();
    await setState({
      epoch: `${Date.now()}-${crypto.randomUUID()}`,
      version: chrome.runtime.getManifest().version,
      enabled: self.enabled !== false,
      updatedAt: Date.now(),
      installReason: details.reason
    });
  } catch (e) { console.error(e); }
});

chrome.runtime.onStartup.addListener(() => {
  refreshEpoch('startup').catch(console.error);
});

// Management events allow us to persist the disabled state before the extension is turned off.
// When it is enabled again, the service worker can detect prev.enabled=false and rotate epoch.
chrome.management.onDisabled.addListener(async info => {
  try {
    if (info.id !== chrome.runtime.id) return;
    const prev = await getState();
    await setState({
      ...prev,
      version: chrome.runtime.getManifest().version,
      enabled: false,
      updatedAt: Date.now()
    });
  } catch (e) { console.error(e); }
});

chrome.management.onEnabled.addListener(async info => {
  try {
    if (info.id !== chrome.runtime.id) return;
    const prev = await getState();
    await setState({
      ...prev,
      epoch: `${Date.now()}-${crypto.randomUUID()}`,
      version: chrome.runtime.getManifest().version,
      enabled: true,
      updatedAt: Date.now()
    });
  } catch (e) { console.error(e); }
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === 'EIMS_GET_EXTENSION_EPOCH') {
    (async () => {
      const self = await chrome.management.getSelf();
      const prev = await getState();
      const version = chrome.runtime.getManifest().version;
      let state = prev;

      if (!prev.epoch || !prev.version || prev.version !== version || prev.enabled === false) {
        state = await refreshEpoch('message');
      } else if (prev.enabled !== (self.enabled !== false)) {
        state = {...prev, enabled:self.enabled !== false, updatedAt:Date.now()};
        await setState(state);
      }
      sendResponse({ok:true, epoch:state.epoch, version});
    })().catch(err => sendResponse({ok:false,error:String(err)}));
    return true;
  }
});


// v16: EIMS 저장 버튼은 일반 DOM click()/dispatchEvent()로는 화면상 클릭처럼 보여도
// 실제 저장 처리가 되지 않는 사례가 확인되어 DevTools Protocol의 실제 마우스 입력 이벤트를 사용한다.
async function dispatchTrustedClick(tabId, x, y) {
  const target = {tabId};
  let attachedHere = false;

  try {
    await chrome.debugger.attach(target, '1.3');
    attachedHere = true;
  } catch (e) {
    // 이미 다른 디버거가 붙어 있을 수 있다. 그 경우 command 전송을 시도한다.
    const msg = String(e || '');
    if (!/already attached|Another debugger/i.test(msg)) throw e;
  }

  try {
    await chrome.debugger.sendCommand(target, 'Input.dispatchMouseEvent', {
      type: 'mouseMoved',
      x, y,
      button: 'none',
      buttons: 0
    });
    await chrome.debugger.sendCommand(target, 'Input.dispatchMouseEvent', {
      type: 'mousePressed',
      x, y,
      button: 'left',
      buttons: 1,
      clickCount: 1
    });
    await chrome.debugger.sendCommand(target, 'Input.dispatchMouseEvent', {
      type: 'mouseReleased',
      x, y,
      button: 'left',
      buttons: 0,
      clickCount: 1
    });
  } finally {
    if (attachedHere) {
      try { await chrome.debugger.detach(target); } catch {}
    }
  }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type !== 'EIMS_TRUSTED_CLICK') return;

  (async () => {
    const tabId = sender.tab?.id;
    if (!tabId) throw new Error('현재 EIMS 탭 ID를 확인하지 못했습니다.');

    const x = Number(msg.x);
    const y = Number(msg.y);
    if (!Number.isFinite(x) || !Number.isFinite(y)) {
      throw new Error('저장 버튼 좌표가 올바르지 않습니다.');
    }

    await dispatchTrustedClick(tabId, x, y);
    sendResponse({ok:true});
  })().catch(err => sendResponse({ok:false, error:String(err?.message || err)}));

  return true;
});


// v22: 브라우저 JavaScript confirm/alert는 Page.javascriptDialogOpening 이벤트에서 즉시 수락한다.
// v21의 polling 방식은 첫 번째 confirm에서 실패하고 두 번째 alert만 처리되는 사례가 확인됨.
function delayV22(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function saveWithDialogEvent(tabId, x, y) {
  const target = {tabId};
  let attachedHere = false;
  const handled = [];
  let resolveFirst;
  let resolveSecond;

  const firstPromise = new Promise(r => { resolveFirst = r; });
  const secondPromise = new Promise(r => { resolveSecond = r; });

  const onEvent = async (source, method, params) => {
    if (source.tabId !== tabId) return;
    if (method !== 'Page.javascriptDialogOpening') return;

    const message = String(params?.message || '');
    const type = String(params?.type || '');

    try {
      await chrome.debugger.sendCommand(target, 'Page.handleJavaScriptDialog', {
        accept: true
      });
      handled.push({message, type, at: Date.now()});

      if (handled.length === 1) resolveFirst({message, type});
      if (handled.length === 2) resolveSecond({message, type});
    } catch (e) {
      console.error('EIMS dialog accept failed:', e);
    }
  };

  try {
    try {
      await chrome.debugger.attach(target, '1.3');
      attachedHere = true;
    } catch (e) {
      const msg = String(e || '');
      if (!/already attached|Another debugger/i.test(msg)) throw e;
    }

    chrome.debugger.onEvent.addListener(onEvent);

    try { await chrome.debugger.sendCommand(target, 'Page.enable'); } catch {}

    // 저장 버튼 실제 마우스 클릭
    await chrome.debugger.sendCommand(target, 'Input.dispatchMouseEvent', {
      type: 'mouseMoved',
      x, y,
      button: 'none',
      buttons: 0
    });
    await chrome.debugger.sendCommand(target, 'Input.dispatchMouseEvent', {
      type: 'mousePressed',
      x, y,
      button: 'left',
      buttons: 1,
      clickCount: 1
    });
    await chrome.debugger.sendCommand(target, 'Input.dispatchMouseEvent', {
      type: 'mouseReleased',
      x, y,
      button: 'left',
      buttons: 0,
      clickCount: 1
    });

    // 첫 confirm 최대 5초, 두 번째 alert 최대 10초
    const first = await Promise.race([
      firstPromise,
      delayV22(5000).then(() => null)
    ]);

    let second = null;
    if (first) {
      second = await Promise.race([
        secondPromise,
        delayV22(10000).then(() => null)
      ]);
    }

    return {
      confirmHandled: !!first,
      processedHandled: !!second,
      dialogs: handled
    };
  } finally {
    try { chrome.debugger.onEvent.removeListener(onEvent); } catch {}
    if (attachedHere) {
      try { await chrome.debugger.detach(target); } catch {}
    }
  }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type !== 'EIMS_SAVE_WITH_NATIVE_DIALOGS') return;

  (async () => {
    const tabId = sender.tab?.id;
    if (!tabId) throw new Error('현재 EIMS 탭 ID를 확인하지 못했습니다.');

    const x = Number(msg.x);
    const y = Number(msg.y);
    if (!Number.isFinite(x) || !Number.isFinite(y)) {
      throw new Error('저장 버튼 좌표가 올바르지 않습니다.');
    }

    const result = await saveWithDialogEvent(tabId, x, y);
    sendResponse({ok:true, ...result});
  })().catch(err => {
    sendResponse({ok:false, error:String(err?.message || err)});
  });

  return true;
});
