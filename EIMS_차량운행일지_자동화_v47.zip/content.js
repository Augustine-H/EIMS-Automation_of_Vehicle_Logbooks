
(() => {
  'use strict';

  if (window.__EIMS_VEHICLE_LOG_V47__) return;
  window.__EIMS_VEHICLE_LOG_V47__ = true;

  const IDS = {
    search: 'mf_tcMain_contents_tab_103002001_body_btnRetrieve',
    addRow: 'mf_tcMain_contents_tab_103002001_body_anchor3',
    dispatch: 'mf_tcMain_contents_tab_103002001_body_btnEgrcstd',
    dispatchClose: 'mf_tcMain_contents_tab_103002001_body_popupEgrcStd_close',
    beginDate: 'mf_tcMain_contents_tab_103002001_body_opratBeginDt_input',
    beginTime: 'mf_tcMain_contents_tab_103002001_body_opratBeginTm',
    endDate: 'mf_tcMain_contents_tab_103002001_body_opratEndDt_input',
    endTime: 'mf_tcMain_contents_tab_103002001_body_opratEndTm',
    destination: 'mf_tcMain_contents_tab_103002001_body_dstn',
    currentDistance: 'mf_tcMain_contents_tab_103002001_body_opratDstnc',
    meter: 'mf_tcMain_contents_tab_103002001_body_inpMeter',
    etcBusins: 'mf_tcMain_contents_tab_103002001_body_etcBusins',
    save: 'mf_tcMain_contents_tab_103002001_body_btnSave',
    delete: 'mf_tcMain_contents_tab_103002001_body_btnDele'
  };

  const OP = {
    '화재': 0, '구조': 1, '구급': 2, '훈련': 3,
    '대민지원': 4, '기타': 5, '시동점검': 6
  };

  const ETC_BUSINS = {
    '화재': ['화재출동'],
    '구조': ['구조출동', '벌집제거', '동물구조', '기타안전사고'],
    '구급': ['구급출동'],
    '훈련': ['훈련출동'],
    '대민지원': ['대민지원'],
    '기타': ['업무운행'],
    '시동점검': ['교대점검', '시동점검', '주간점검']
  };

  const ETC_RECENT_KEY = 'eimsVehicleLogEtcBusinsRecent';
  const VEHICLES={'998수5175':'앙성20호','998수5124':'앙성30호','998수5145':'앙성109호','47모9366':'앙성5호'};

  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const $ = id => document.getElementById(id);

  function status(msg, ok=true) {
    const el = document.getElementById('eims-vlog-status');
    if (el) {
      el.textContent = msg;
      el.style.color = ok ? '#d9f99d' : '#fecaca';
    }
    console.log('[EIMS 차량운행일지]', msg);
  }

  function clickLikeUser(el, dbl=false) {
    if (!el) return false;
    try { el.scrollIntoView({block:'center', inline:'nearest'}); } catch {}
    const opts = {bubbles:true, cancelable:true, composed:true, view:window};
    try { el.focus?.(); } catch {}

    // v4: 일반 클릭은 반드시 1회만 발생시킨다.
    // 이전 버전은 dispatchEvent('click') 후 el.click()까지 실행하여
    // 행추가 같은 버튼이 두 번 눌릴 가능성이 있었다.
    try {
      if (window.PointerEvent) el.dispatchEvent(new PointerEvent('pointerdown', opts));
    } catch {}
    try { el.dispatchEvent(new MouseEvent('mousedown', opts)); } catch {}
    try { el.dispatchEvent(new MouseEvent('mouseup', opts)); } catch {}

    if (dbl) {
      // 더블클릭 대상은 click 2회 + dblclick 1회로 전달
      try { el.dispatchEvent(new MouseEvent('click', {...opts, detail:1})); } catch {}
      try { el.dispatchEvent(new MouseEvent('click', {...opts, detail:2})); } catch {}
      try { el.dispatchEvent(new MouseEvent('dblclick', {...opts, detail:2})); } catch {}
    } else {
      try { el.dispatchEvent(new MouseEvent('click', {...opts, detail:1})); } catch {
        try { el.click(); } catch {}
      }
    }
    return true;
  }

  function setValue(el, value) {
    if (!el) return false;
    const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const desc = Object.getOwnPropertyDescriptor(proto, 'value');
    try { desc?.set?.call(el, String(value)); } catch { el.value = String(value); }
    for (const ev of ['input','change','blur']) {
      try { el.dispatchEvent(new Event(ev, {bubbles:true})); } catch {}
    }
    return true;
  }

  async function setValueVerified(el,value,label='입력값') {
    if(!el) throw new Error(`${label} 입력칸을 찾지 못했습니다.`);
    const v=String(value);
    for(let i=0;i<3;i++){
      setValue(el,v);
      try{el.focus();}catch{}
      for(const ev of ['input','change','blur']){try{el.dispatchEvent(new Event(ev,{bubbles:true,cancelable:true}));}catch{}}
      await sleep(150);
      if(String(el.value||'').trim()===v.trim()) return true;
    }
    throw new Error(`${label} 입력이 EIMS 화면에 반영되지 않았습니다.`);
  }

  async function typeLikeUser(el, value, label='입력값') {
    if (!el) throw new Error(`${label} 입력칸을 찾지 못했습니다.`);
    const v = String(value);

    try { el.scrollIntoView({block:'center'}); } catch {}
    try { el.focus(); } catch {}

    // 기존 값 전체 선택
    try {
      if (typeof el.select === 'function') el.select();
      else el.setSelectionRange?.(0, String(el.value||'').length);
    } catch {}

    // 브라우저의 실제 텍스트 입력 경로를 우선 사용
    let inserted = false;
    try {
      inserted = document.execCommand('insertText', false, v);
    } catch {}

    if (!inserted || String(el.value||'') !== v) {
      try {
        el.value = '';
        el.dispatchEvent(new InputEvent('input', {
          bubbles:true, cancelable:false, inputType:'deleteContentBackward', data:null
        }));
      } catch {}

      // 글자 단위로 넣어 WebSquare가 키 입력 흐름을 받을 기회를 준다.
      let built = '';
      for (const ch of v) {
        try {
          el.dispatchEvent(new KeyboardEvent('keydown', {bubbles:true,cancelable:true,key:ch}));
          el.dispatchEvent(new KeyboardEvent('keypress', {bubbles:true,cancelable:true,key:ch}));
        } catch {}

        built += ch;
        try {
          const proto = HTMLInputElement.prototype;
          const desc = Object.getOwnPropertyDescriptor(proto, 'value');
          if (desc?.set) desc.set.call(el, built); else el.value = built;
        } catch { el.value = built; }

        try {
          el.dispatchEvent(new InputEvent('beforeinput', {
            bubbles:true, cancelable:true, inputType:'insertText', data:ch
          }));
        } catch {}
        try {
          el.dispatchEvent(new InputEvent('input', {
            bubbles:true, cancelable:false, inputType:'insertText', data:ch
          }));
        } catch {}
        try { el.dispatchEvent(new KeyboardEvent('keyup', {bubbles:true,cancelable:true,key:ch})); } catch {}
        await sleep(10);
      }
    }

    try { el.dispatchEvent(new Event('change', {bubbles:true,cancelable:true})); } catch {}
    try { el.blur(); } catch {}
    await sleep(200);

    if (String(el.value||'').trim() !== v.trim()) {
      throw new Error(`${label} 입력값이 화면에 유지되지 않았습니다.`);
    }
    return true;
  }

  async function waitFor(fn, timeout=7000, step=100) {
    const started = Date.now();
    while (Date.now() - started < timeout) {
      const v = fn();
      if (v) return v;
      await sleep(step);
    }
    return null;
  }

  function visible(el) {
    if (!el) return false;
    const s = getComputedStyle(el);
    return s.display !== 'none' && s.visibility !== 'hidden' && el.getClientRects().length > 0;
  }

  async function waitLoadingGone(timeout=15000) {
    const started = Date.now();
    while (Date.now()-started < timeout) {
      const loaders = [...document.querySelectorAll('#processMsgLayer,.pro_loading,.ly_loading')]
        .filter(visible);
      if (!loaders.length) return true;
      await sleep(150);
    }
    return false;
  }

  function findVehicleCell(vehicleNo) {
    return [...document.querySelectorAll('td[col_id="mvEqpmnNo"]')]
      .find(td => (td.textContent||'').replace(/\s/g,'') === vehicleNo.replace(/\s/g,''));
  }

  function dispatchRowsForVehicle(vehicleNo) {
    return [...document.querySelectorAll(
      'td[col_id="carNo"][id*="popupEgrcStd_wframe_gridView1_cell_"]'
    )].filter(td => (td.textContent||'').replace(/\s/g,'') === vehicleNo.replace(/\s/g,''));
  }

  function rowInfo(cell) {
    const tr = cell.closest('tr');
    if (!tr) return {cell, text:(cell.textContent||'').trim()};
    const get = col => (tr.querySelector(`td[col_id="${col}"]`)?.textContent||'').trim();
    const no = (tr.querySelector('td.gridBodyDefault_rowNumber')?.textContent || '').trim();
    return {
      cell,
      tr,
      no,
      start: get('strDtime'),
      end: get('arrDtime'),
      car: get('carNo'),
      kind: get('dsrKndCls') || get('dsrKnd'),
      addr: get('dsrAddr')
    };
  }

  function modal(title, bodyBuilder, width=440) {
    return new Promise(resolve => {
      const overlay = document.createElement('div');
      overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.38);z-index:2147483647;display:flex;align-items:center;justify-content:center;';
      const box = document.createElement('div');
      box.style.cssText = `width:${width}px;max-width:94vw;max-height:86vh;overflow:auto;background:#fff;color:#111;border-radius:10px;box-shadow:0 12px 40px rgba(0,0,0,.35);padding:18px;font:14px/1.45 Arial,"Malgun Gothic",sans-serif;`;
      box.innerHTML = `<div style="font-size:18px;font-weight:700;margin-bottom:12px">${title}</div>`;
      const api = {box, close:(v)=>{overlay.remove();resolve(v)}};
      bodyBuilder(api);
      overlay.appendChild(box);
      document.body.appendChild(overlay);
    });
  }

  async function chooseDispatch(matches) {
    return modal('출동정보 선택', ({box, close}) => {
      box.style.width='980px';
      box.style.maxWidth='96vw';
      box.style.maxHeight='88vh';
      box.style.overflow='hidden';

      const title = box.firstElementChild;
      if (title) {
        title.style.cssText += ';cursor:move;user-select:none;padding-bottom:8px;border-bottom:1px solid #ddd;';
        title.title='드래그해서 창 이동';
      }

      const rows = matches.map(rowInfo);
      let page = 0;
      const pageSize = 10;
      const totalPages = Math.max(1, Math.ceil(rows.length / pageSize));
      let selected = null;

      const info = document.createElement('div');
      info.style.cssText='margin-bottom:10px;color:#444;';
      info.textContent=`현재 차량의 출동정보가 ${rows.length}건 있습니다. 사용할 출동 건을 선택하세요.`;
      box.appendChild(info);

      const tableWrap=document.createElement('div');
      tableWrap.style.cssText='max-height:520px;overflow:auto;border:1px solid #ccc;border-radius:6px;';
      tableWrap.innerHTML=`
        <table style="width:100%;border-collapse:collapse;font-size:13px;table-layout:fixed">
          <thead>
            <tr style="background:#f3f4f6;position:sticky;top:0;z-index:1">
              <th style="width:48px;padding:8px;border-bottom:1px solid #ccc">No.</th>
              <th style="width:155px;padding:8px;border-bottom:1px solid #ccc">출동일시</th>
              <th style="width:155px;padding:8px;border-bottom:1px solid #ccc">종료일시</th>
              <th style="width:105px;padding:8px;border-bottom:1px solid #ccc">차량번호</th>
              <th style="width:120px;padding:8px;border-bottom:1px solid #ccc">재난유형</th>
              <th style="padding:8px;border-bottom:1px solid #ccc">목적지(주소)</th>
            </tr>
          </thead>
          <tbody id="eims-dispatch-choice-body"></tbody>
        </table>`;
      box.appendChild(tableWrap);

      const nav=document.createElement('div');
      nav.style.cssText='display:flex;align-items:center;justify-content:center;gap:10px;margin-top:12px;flex-wrap:wrap;';
      nav.innerHTML=`
        <div id="eims-dispatch-prev" role="button" tabindex="0" style="padding:7px 12px;background:#eee;border:1px solid #bbb;border-radius:5px;cursor:pointer">이전</div>
        <span id="eims-dispatch-page"></span>
        <div id="eims-dispatch-next" role="button" tabindex="0" style="padding:7px 12px;background:#eee;border:1px solid #bbb;border-radius:5px;cursor:pointer">다음</div>
        <span style="margin-left:10px;font-weight:700">남은 시간: <span id="eims-dispatch-sec">30</span>초</span>
        <div id="eims-dispatch-extend" role="button" tabindex="0"
             style="padding:6px 10px;background:#fff;border:1px solid #60a5fa;border-radius:5px;cursor:pointer;font-weight:700;color:#1d4ed8">시간 늘리기</div>`;
      box.appendChild(nav);

      const actions=document.createElement('div');
      actions.style.cssText='display:flex;justify-content:center;gap:12px;margin-top:14px;padding-top:12px;border-top:1px solid #ddd;';
      actions.innerHTML=`
        <div id="eims-dispatch-apply" role="button" tabindex="0" style="min-width:82px;padding:9px 18px;background:#222;color:#fff;font-weight:700;text-align:center;border-radius:5px;cursor:pointer">적용</div>
        <div id="eims-dispatch-cancel" role="button" tabindex="0" style="min-width:82px;padding:9px 18px;background:#555;color:#fff;font-weight:700;text-align:center;border-radius:5px;cursor:pointer">취소</div>`;
      box.appendChild(actions);

      const render=()=>{
        const tbody=box.querySelector('#eims-dispatch-choice-body');
        const slice=rows.slice(page*pageSize,(page+1)*pageSize);
        tbody.innerHTML='';
        slice.forEach((r,i)=>{
          const tr=document.createElement('tr');
          const globalIndex=page*pageSize+i;
          tr.style.cssText='cursor:pointer;background:#fff;';
          tr.innerHTML=`
            <td style="padding:8px;border-bottom:1px solid #eee;text-align:center">${r.no || (globalIndex+1)}</td>
            <td style="padding:8px;border-bottom:1px solid #eee;text-align:center">${r.start||''}</td>
            <td style="padding:8px;border-bottom:1px solid #eee;text-align:center">${r.end||''}</td>
            <td style="padding:8px;border-bottom:1px solid #eee;text-align:center">${r.car||''}</td>
            <td style="padding:8px;border-bottom:1px solid #eee;text-align:center">${r.kind||''}</td>
            <td style="padding:8px;border-bottom:1px solid #eee">${r.addr||''}</td>`;
          if(selected===globalIndex) tr.style.background='#e8f0fe';
          tr.onclick=()=>{selected=globalIndex;render();};
          tr.ondblclick=()=>box.__eimsDispatchFinish ? box.__eimsDispatchFinish(globalIndex) : close(matches[globalIndex]);
          tbody.appendChild(tr);
        });

        box.querySelector('#eims-dispatch-page').textContent =
          `${page+1} / ${totalPages} 페이지 · ${page*pageSize+1}-${Math.min((page+1)*pageSize,rows.length)} / ${rows.length}건`;

        const prev=box.querySelector('#eims-dispatch-prev');
        const next=box.querySelector('#eims-dispatch-next');
        prev.style.opacity=page===0?'.4':'1';
        next.style.opacity=page>=totalPages-1?'.4':'1';
      };

      box.querySelector('#eims-dispatch-prev').onclick=()=>{
        if(page>0){page--;render();}
      };
      box.querySelector('#eims-dispatch-next').onclick=()=>{
        if(page<totalPages-1){page++;render();}
      };
      box.querySelector('#eims-dispatch-apply').onclick=()=>{
        if(selected===null){
          alert('출동정보를 선택해 주세요.');
          return;
        }
        close(matches[selected]);
      };
      box.querySelector('#eims-dispatch-cancel').onclick=()=>close(null);

      // 드래그 이동
      let dragging=false,ox=0,oy=0;
      if(title){
        title.addEventListener('mousedown',e=>{
          if(e.button!==0)return;
          const rect=box.getBoundingClientRect();
          dragging=true;
          ox=e.clientX-rect.left;
          oy=e.clientY-rect.top;
          box.style.position='fixed';
          box.style.left=rect.left+'px';
          box.style.top=rect.top+'px';
          box.style.margin='0';
          box.style.zIndex='2147483647';
          e.preventDefault();
        });
      }

      const onMove=e=>{
        if(!dragging)return;
        const maxX=Math.max(0,window.innerWidth-box.offsetWidth);
        const maxY=Math.max(0,window.innerHeight-box.offsetHeight);
        box.style.left=Math.min(maxX,Math.max(0,e.clientX-ox))+'px';
        box.style.top=Math.min(maxY,Math.max(0,e.clientY-oy))+'px';
      };
      const onUp=()=>{dragging=false;};
      document.addEventListener('mousemove',onMove);
      document.addEventListener('mouseup',onUp);

      // v28: 출동정보 선택창 30초 카운트다운.
      // 시간 내 적용/더블클릭/취소가 없으면 자동으로 취소 처리.
      let remaining=30;
      let finished=false;

      const stopTimer=()=>{
        if(finished)return;
        finished=true;
        clearInterval(timer);
      };

      const cancelAndClose=()=>{
        if(finished)return;
        stopTimer();
        close(null);
      };

      const timer=setInterval(()=>{
        if(finished)return;
        remaining--;
        const sec=box.querySelector('#eims-dispatch-sec');
        if(sec)sec.textContent=remaining;

        if(remaining<=0){
          stopTimer();
          close(null);
        }
      },1000);

      const extend=box.querySelector('#eims-dispatch-extend');
      const extendTime=()=>{
        if(finished)return;
        remaining+=60;
        const sec=box.querySelector('#eims-dispatch-sec');
        if(sec)sec.textContent=remaining;
      };
      extend.onclick=extendTime;
      extend.onkeydown=e=>{
        if(e.key==='Enter'||e.key===' '){
          e.preventDefault();
          extendTime();
        }
      };

      // 기존 적용/취소 이벤트를 타이머 정리 포함 방식으로 교체
      box.querySelector('#eims-dispatch-apply').onclick=()=>{
        if(selected===null){
          alert('출동정보를 선택해 주세요.');
          return;
        }
        stopTimer();
        close(matches[selected]);
      };
      box.querySelector('#eims-dispatch-cancel').onclick=cancelAndClose;

      // 행 더블클릭도 타이머 종료 후 적용되도록 재렌더에서 사용하는 함수 제공
      box.__eimsDispatchFinish = idx => {
        stopTimer();
        close(matches[idx]);
      };

      render();
    }, 980);
  }

  function parseLocal(yyyymmdd, hhmm) {
    if (!/^\d{8}$/.test(yyyymmdd) || !/^\d{4}$/.test(hhmm)) return null;
    const y=+yyyymmdd.slice(0,4), m=+yyyymmdd.slice(4,6), d=+yyyymmdd.slice(6,8);
    const h=+hhmm.slice(0,2), min=+hhmm.slice(2,4);
    if (m<1||m>12||d<1||d>31||h>23||min>59) return null;
    const dt = new Date(y,m-1,d,h,min,0,0);
    if (dt.getFullYear()!==y || dt.getMonth()!==m-1 || dt.getDate()!==d || dt.getHours()!==h || dt.getMinutes()!==min) return null;
    return dt;
  }

  async function commitManualDateTimeFields(t) {
    const bd = $(IDS.beginDate);
    const bt = $(IDS.beginTime);
    const ed = $(IDS.endDate);
    const et = $(IDS.endTime);

    if (!bd || !bt || !ed || !et) {
      throw new Error('운행시간 입력칸을 찾지 못했습니다.');
    }

    // 사용자가 직접 입력한 뒤 다른 칸을 클릭했을 때
    // yyyyMMdd / HHmm 값이 yyyy-MM-dd / HH:mm 형태로 확정되는 WebSquare 동작을 재현한다.
    try { await typeLikeUser(bd, t.bd, '운행 시작일자'); }
    catch { await setValueVerified(bd, t.bd, '운행 시작일자'); }

    // 다음 필드로 포커스를 이동시켜 시작일자 편집값 commit
    try { bt.focus(); } catch {}
    await sleep(120);

    try { await typeLikeUser(bt, t.bt, '운행 시작시간'); }
    catch { await setValueVerified(bt, t.bt, '운행 시작시간'); }

    try { ed.focus(); } catch {}
    await sleep(180);

    try { await typeLikeUser(ed, t.ed, '운행 종료일자'); }
    catch { await setValueVerified(ed, t.ed, '운행 종료일자'); }

    try { et.focus(); } catch {}
    await sleep(120);

    try { await typeLikeUser(et, t.et, '운행 종료시간'); }
    catch { await setValueVerified(et, t.et, '운행 종료시간'); }

    // 시간 입력 후 실제 사용자처럼 다른 입력칸으로 이동하여 HHmm → HH:mm 포맷을 확정.
    const commitTarget = $(IDS.destination) || $(IDS.etcBusins) || $(IDS.save);
    try { commitTarget?.focus?.(); } catch {}
    try { et.blur?.(); } catch {}
    try { ed.blur?.(); } catch {}
    try { bt.blur?.(); } catch {}
    try { bd.blur?.(); } catch {}

    // WebSquare 포맷터가 비동기로 적용되는 시간을 확보.
    await sleep(700);

    // 한 번 더 change/blur를 전달해 포맷이 안 된 상태로 저장되는 것을 방지.
    for (const el of [bd, bt, ed, et]) {
      try { el.dispatchEvent(new Event('change', {bubbles:true,cancelable:true})); } catch {}
      try { el.blur?.(); } catch {}
    }
    try { commitTarget?.focus?.(); } catch {}
    await sleep(500);

    // 핵심 검증: 시간칸이 여전히 1234 같은 편집 문자열이면 저장 단계로 넘기지 않는다.
    // EIMS에서 정상 확정된 화면은 12:34처럼 표시되는 것이 사용자 테스트로 확인됨.
    const normalize = v => String(v ?? '').trim();
    const isRawHHmm = v => /^\d{4}$/.test(normalize(v));
    const isFormattedHHmm = v => /^\d{1,2}:\d{2}$/.test(normalize(v));

    let beginShown = normalize(bt.value);
    let endShown = normalize(et.value);

    if (isRawHHmm(beginShown) || isRawHHmm(endShown)) {
      // 실제 사용자가 다른 칸을 클릭하는 동작을 한 번 더 재현
      try { commitTarget?.click?.(); } catch {}
      try { commitTarget?.focus?.(); } catch {}
      await sleep(700);
      beginShown = normalize(bt.value);
      endShown = normalize(et.value);
    }

    if (!(isFormattedHHmm(beginShown) && isFormattedHHmm(endShown))) {
      throw new Error(
        `운행시간 형식이 EIMS에서 확정되지 않았습니다. ` +
        `현재 표시: ${beginShown || '(빈값)'} ~ ${endShown || '(빈값)'}. ` +
        `HH:mm 형식으로 바뀐 뒤 다시 실행해 주세요.`
      );
    }

    return true;
  }

  async function manualTimeDialog() {
    const now = new Date();
    const pad=n=>String(n).padStart(2,'0');
    const formatDate=d=>`${d.getFullYear()}${pad(d.getMonth()+1)}${pad(d.getDate())}`;
    const formatTime=d=>`${pad(d.getHours())}${pad(d.getMinutes())}`;
    const formatTimeDisplay=d=>`${pad(d.getHours())}:${pad(d.getMinutes())}`;

    const today=formatDate(now);
    const hhmm=formatTime(now);

    return modal('운행시간 수동 입력', ({box, close}) => {
      box.style.paddingBottom = '16px';

      box.insertAdjacentHTML('beforeend', `
        <div style="display:grid;grid-template-columns:64px 170px 125px;column-gap:10px;row-gap:10px;
                    align-items:center;justify-content:center;margin-top:4px">
          <div></div>
          <div style="font-size:13px;font-weight:700;text-align:center;color:#222">날짜(yyyyMMdd)</div>
          <div style="font-size:13px;font-weight:700;text-align:center;color:#222">시간(HHmm)</div>

          <div style="font-weight:700;text-align:center">시작</div>
          <input id="eims-md-bd" value="${today}" style="width:170px;box-sizing:border-box">
          <input id="eims-md-bt" placeholder="HHmm" style="width:125px;box-sizing:border-box">

          <div style="font-weight:700;text-align:center">종료</div>
          <input id="eims-md-ed" value="${today}" style="width:170px;box-sizing:border-box">
          <input id="eims-md-et" value="${hhmm}" style="width:125px;box-sizing:border-box">
        </div>

        <div style="margin-top:14px;padding:10px 12px;background:#eff6ff;border:1px solid #93c5fd;border-radius:6px">
          <div style="font-size:12px;color:#1e3a8a;text-align:center;white-space:nowrap">
            1분 내 미입력시 종료시간 1분 전으로 자동 입력합니다.
          </div>
          <div style="display:flex;align-items:center;justify-content:center;gap:10px;margin-top:8px">
            <b style="white-space:nowrap">남은 시간: <span id="eims-md-sec">60</span>초</b>
            <div id="eims-md-extend" role="button" tabindex="0"
                 style="padding:5px 9px;background:#fff;border:1px solid #60a5fa;border-radius:5px;
                        cursor:pointer;font-size:12px;font-weight:700;color:#1d4ed8">시간 늘리기</div>
            <div id="eims-md-auto" role="button" tabindex="0"
                 style="padding:5px 9px;background:#fff;border:1px solid #16a34a;border-radius:5px;
                        cursor:pointer;font-size:12px;font-weight:700;color:#166534">자동 입력</div>
          </div>
        </div>

        <div id="eims-md-error" style="min-height:24px;color:#b91c1c;margin-top:10px;font-weight:700"></div>

        <div style="display:flex;justify-content:center;gap:12px;margin-top:14px;padding-top:12px;border-top:1px solid #ddd">
          <div id="eims-md-apply" role="button" tabindex="0"
               style="min-width:82px;padding:9px 18px;background:#222;color:#fff;font-size:14px;font-weight:700;
                      text-align:center;border-radius:5px;cursor:pointer;line-height:20px;text-indent:0;letter-spacing:0">적용</div>
          <div id="eims-md-cancel" role="button" tabindex="0"
               style="min-width:82px;padding:9px 18px;background:#555;color:#fff;font-size:14px;font-weight:700;
                      text-align:center;border-radius:5px;cursor:pointer;line-height:20px;text-indent:0;letter-spacing:0">취소</div>
        </div>
      `);

      for (const inp of box.querySelectorAll('input')) {
        inp.style.cssText='padding:7px;border:1px solid #aaa;border-radius:5px;background:#fff;color:#111;font-size:14px;line-height:20px;text-indent:0;';
      }

      let remaining=60;
      let finished=false;

      const finish=value=>{
        if(finished)return;
        finished=true;
        clearInterval(timer);
        close(value);
      };

      const readAndValidate=()=>{
        const bd=box.querySelector('#eims-md-bd').value.trim();
        const bt=box.querySelector('#eims-md-bt').value.trim();
        const ed=box.querySelector('#eims-md-ed').value.trim();
        const et=box.querySelector('#eims-md-et').value.trim();
        const start=parseLocal(bd,bt), end=parseLocal(ed,et);
        const err=box.querySelector('#eims-md-error');

        if (!start || !end) {
          err.textContent='날짜는 yyyyMMdd, 시간은 HHmm 형식으로 정확히 입력해 주세요.';
          return null;
        }
        if (end < start) {
          err.textContent='운행 종료일시는 시작일시보다 빠를 수 없습니다.';
          return null;
        }

        const current = new Date();
        if (end > current) {
          err.textContent='운행 종료일시가 현재 날짜/시간보다 이후입니다.';
          alert(`[입력 확인]\n운행 종료일시가 현재 날짜/시간보다 이후로 입력되었습니다.\n종료 날짜와 시간을 다시 확인해 주세요.\n\n입력 종료일시: ${ed} ${et}\n현재 시각: ${current.getFullYear()}-${pad(current.getMonth()+1)}-${pad(current.getDate())} ${pad(current.getHours())}:${pad(current.getMinutes())}`);
          return null;
        }

        return {bd,bt,ed,et};
      };

      const doApply=()=>{
        const value=readAndValidate();
        if(value)finish(value);
      };

      const autoApplyFromEnd=()=>{
        if(finished)return;

        const ed=box.querySelector('#eims-md-ed').value.trim();
        const et=box.querySelector('#eims-md-et').value.trim();
        let end=parseLocal(ed,et);

        // 종료값이 사용 중 수정되어 유효하지 않으면 팝업 생성 당시 현재시각을 종료값으로 사용
        if(!end || end > new Date()){
          end=new Date();
        }

        const begin=new Date(end.getTime()-60*1000);
        const autoValue={
          bd:formatDate(begin),
          bt:formatTimeDisplay(begin),
          ed:formatDate(end),
          et:formatTimeDisplay(end)
        };

        // 사용자에게 실제 적용되는 값을 잠깐 표시
        box.querySelector('#eims-md-bd').value=autoValue.bd;
        box.querySelector('#eims-md-bt').value=autoValue.bt;
        box.querySelector('#eims-md-ed').value=autoValue.ed;
        box.querySelector('#eims-md-et').value=autoValue.et;

        finish(autoValue);
      };

      const timer=setInterval(()=>{
        if(finished)return;
        remaining--;
        const sec=box.querySelector('#eims-md-sec');
        if(sec)sec.textContent=remaining;

        if(remaining<=0){
          autoApplyFromEnd();
        }
      },1000);

      const apply=box.querySelector('#eims-md-apply');
      const cancel=box.querySelector('#eims-md-cancel');
      const extend=box.querySelector('#eims-md-extend');
      const auto=box.querySelector('#eims-md-auto');

      const extendTime=()=>{
        if(finished)return;
        remaining+=60;
        const sec=box.querySelector('#eims-md-sec');
        if(sec)sec.textContent=remaining;
      };

      extend.onclick=extendTime;
      extend.onkeydown=e=>{
        if(e.key==='Enter'||e.key===' '){
          e.preventDefault();
          extendTime();
        }
      };

      // 카운트가 끝난 것과 동일하게 종료시간 기준 1분 전을 시작시간으로 자동 계산해 즉시 적용
      auto.onclick=autoApplyFromEnd;
      auto.onkeydown=e=>{
        if(e.key==='Enter'||e.key===' '){
          e.preventDefault();
          autoApplyFromEnd();
        }
      };

      apply.onclick=doApply;
      apply.onkeydown=e=>{
        if(e.key==='Enter'||e.key===' '){
          e.preventDefault();
          doApply();
        }
      };

      cancel.onclick=()=>finish(null);
      cancel.onkeydown=e=>{
        if(e.key==='Enter'||e.key===' '){
          e.preventDefault();
          finish(null);
        }
      };
    }, 590);
  }

  async function distanceDialog() {
    return modal('운행거리 입력', ({box, close}) => {
      box.insertAdjacentHTML('beforeend', `
        <div style="margin-bottom:8px">둘 중 한 가지 방식으로 입력하세요.</div>
        <label style="display:block;margin:7px 0">운행거리(금회)
          <input id="eims-dist-current" type="number" min="0" step="1" style="width:180px">
        </label>
        <label style="display:block;margin:7px 0">차량 계기판 운행거리
          <input id="eims-dist-meter" type="number" min="0" step="1" style="width:180px">
        </label>

        <div id="eims-dist-warn" style="margin-top:12px;padding:10px;background:#fff7ed;border:1px solid #fdba74;border-radius:6px">
          운행거리를 입력해 주세요. 30초 내 미입력시 0으로 입력됩니다.<br>
          <div style="display:flex;align-items:center;gap:8px;margin-top:4px">
            <b>남은 시간: <span id="eims-dist-sec">30</span>초</b>
            <div id="eims-dist-extend" role="button" tabindex="0"
                 style="padding:4px 8px;background:#fff;border:1px solid #fb923c;border-radius:4px;
                        cursor:pointer;font-weight:700;color:#9a3412">시간 연장</div>
          </div>
        </div>

        <div style="display:flex;justify-content:center;gap:12px;margin-top:14px;padding-top:12px;border-top:1px solid #ddd">
          <div id="eims-dist-apply" role="button" tabindex="0"
               style="min-width:82px;padding:9px 18px;background:#222;color:#fff;font-size:14px;font-weight:700;
                      text-align:center;border-radius:5px;cursor:pointer;line-height:20px;text-indent:0;letter-spacing:0">적용</div>
          <div id="eims-dist-cancel" role="button" tabindex="0"
               style="min-width:82px;padding:9px 18px;background:#555;color:#fff;font-size:14px;font-weight:700;
                      text-align:center;border-radius:5px;cursor:pointer;line-height:20px;text-indent:0;letter-spacing:0">취소</div>
        </div>
      `);

      let remaining = 30;
      let finished = false;

      const finish = value => {
        if (finished) return;
        finished = true;
        clearInterval(timer);
        close(value);
      };

      const timer = setInterval(() => {
        if (finished) return;
        remaining--;
        const s = box.querySelector('#eims-dist-sec');
        if (s) s.textContent = remaining;

        if (remaining <= 0) {
          finish({type:'current', value:'0', timeout:true});
        }
      }, 1000);

      const doApply = () => {
        const cur = box.querySelector('#eims-dist-current').value.trim();
        const meter = box.querySelector('#eims-dist-meter').value.trim();

        if (cur !== '' && meter !== '') {
          alert('두 항목 중 하나만 입력해 주세요.');
          return;
        }

        // 둘 다 비어 있으면 사용자가 확인하지 않은 것으로 간주하고 타이머 유지
        if (cur === '' && meter === '') {
          return;
        }

        if (cur !== '') finish({type:'current', value:cur});
        else finish({type:'meter', value:meter});
      };

      const doCancel = () => finish(null);

      const apply = box.querySelector('#eims-dist-apply');
      const cancel = box.querySelector('#eims-dist-cancel');
      const extend = box.querySelector('#eims-dist-extend');

      const extendTime = () => {
        remaining += 60;
        const s = box.querySelector('#eims-dist-sec');
        if (s) s.textContent = remaining;
      };
      extend.onclick = extendTime;
      extend.onkeydown = e => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          extendTime();
        }
      };

      apply.onclick = doApply;
      apply.onkeydown = e => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          doApply();
        }
      };

      cancel.onclick = doCancel;
      cancel.onkeydown = e => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          doCancel();
        }
      };
    }, 470);
  }

  function normalizeDateText(v) {
    return String(v||'').replace(/\D/g,'').slice(0,8);
  }
  function normalizeTimeText(v) {
    return String(v||'').replace(/\D/g,'').slice(0,4);
  }
  function currentFormSnapshot(opType) {
    return {
      date: normalizeDateText($(IDS.beginDate)?.value),
      begin: normalizeTimeText($(IDS.beginTime)?.value),
      end: normalizeTimeText($(IDS.endTime)?.value),
      op: opType || '',
      etc: String($(IDS.etcBusins)?.value||'').trim(),
      destination: String($(IDS.destination)?.value||'').trim(),
      distance: String($(IDS.currentDistance)?.value||'').replace(/,/g,'').trim()
    };
  }
  function rowMatchesFormSnapshot(tr, snap) {
    const r = operationRowSignature(tr);
    if (!r) return false;
    const rowDate = String(r.date||'').replace(/\D/g,'');
    const rowBegin = String(r.begin||'').replace(/\D/g,'').slice(0,4);
    const rowEnd = String(r.end||'').replace(/\D/g,'').slice(0,4);
    return (
      (!snap.date || rowDate === snap.date) &&
      (!snap.begin || rowBegin === snap.begin) &&
      (!snap.end || rowEnd === snap.end) &&
      (!snap.op || r.op === snap.op) &&
      (!snap.etc || r.etc === snap.etc) &&
      (!snap.destination || r.destination === snap.destination) &&
      (!snap.distance || String(r.distance||'').replace(/,/g,'') === snap.distance)
    );
  }
  function assertCommittedTimeFormatBeforeSave() {
    const bt = $(IDS.beginTime);
    const et = $(IDS.endTime);
    if (!bt || !et) return true;

    const b = String(bt.value || '').trim();
    const e = String(et.value || '').trim();
    const ok = /^\d{1,2}:\d{2}$/.test(b) && /^\d{1,2}:\d{2}$/.test(e);

    if (!ok) {
      throw new Error(
        `저장을 중단했습니다. 운행시간이 아직 EIMS 확정 형식(HH:mm)이 아닙니다: ` +
        `${b || '(빈값)'} ~ ${e || '(빈값)'}`
      );
    }
    return true;
  }

  async function forceCommitInputs() {
    const ids=[IDS.beginDate,IDS.beginTime,IDS.endDate,IDS.endTime,IDS.destination,IDS.currentDistance,IDS.meter,IDS.etcBusins];
    for(const id of ids){
      const el=$(id);
      if(!el) continue;
      try{el.focus?.();}catch{}
      try{el.dispatchEvent(new Event('input',{bubbles:true,cancelable:true}));}catch{}
      try{el.dispatchEvent(new Event('change',{bubbles:true,cancelable:true}));}catch{}
      try{el.blur?.();}catch{}
      await sleep(70);
    }

    // 마지막 시간 필드가 편집 상태로 남지 않도록 목적지 → 저장 버튼 순으로 포커스 이동
    try{$(IDS.destination)?.focus?.();}catch{}
    await sleep(180);
    try{$(IDS.save)?.focus?.();}catch{}
    await sleep(350);
  }
  function operationSignatureCounts() {
    const counts = new Map();
    for (const tr of operationGridRows()) {
      const sig = JSON.stringify(operationRowSignature(tr));
      counts.set(sig, (counts.get(sig) || 0) + 1);
    }
    return counts;
  }

  function findNewMatchingSavedRow(snapshot, beforeCounts) {
    const currentCounts = operationSignatureCounts();

    for (const tr of operationGridRows()) {
      if (!rowMatchesFormSnapshot(tr, snapshot)) continue;
      const sig = JSON.stringify(operationRowSignature(tr));
      const before = beforeCounts.get(sig) || 0;
      const now = currentCounts.get(sig) || 0;
      if (now > before) return tr;
    }
    return null;
  }

  async function waitForSavedRow(snapshot, beforeCounts, timeout=30000) {
    const start=Date.now();
    while(Date.now()-start < timeout){
      await waitLoadingGone(1500);
      const found = findNewMatchingSavedRow(snapshot, beforeCounts);
      if(found) return found;
      await sleep(400);
    }
    return null;
  }

  function sendRuntimeMessage(message) {
    return new Promise((resolve, reject) => {
      try {
        chrome.runtime.sendMessage(message, res => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
            return;
          }
          if (!res?.ok) {
            reject(new Error(res?.error || '확장 프로그램 메시지 처리 실패'));
            return;
          }
          resolve(res);
        });
      } catch (e) {
        reject(e);
      }
    });
  }

  function isVisibleElement(el) {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    const st = getComputedStyle(el);
    return r.width > 0 && r.height > 0 && st.display !== 'none' && st.visibility !== 'hidden' && st.opacity !== '0';
  }

  function findVisibleConfirmButton(messageNeedle='') {
    const candidates = [...document.querySelectorAll('a,button,input[type="button"],input[type="submit"],[role="button"]')]
      .filter(isVisibleElement);

    // 메시지 팝업 안의 '확인' 버튼을 우선 찾는다.
    for (const el of candidates) {
      const txt = (el.textContent || el.value || '').trim();
      if (txt !== '확인') continue;

      // 가장 가까운 팝업성 컨테이너에서 메시지 문구 확인
      let p = el;
      for (let i=0; i<8 && p; i++, p=p.parentElement) {
        const t = (p.textContent || '').replace(/\s+/g,' ');
        if (!messageNeedle || t.includes(messageNeedle)) return el;
      }
    }

    // 문구 확인이 실패해도 화면에 확인 버튼이 하나뿐이면 사용
    const confirms = candidates.filter(el => ((el.textContent || el.value || '').trim() === '확인'));
    if (confirms.length === 1) return confirms[0];

    return null;
  }

  async function trustedClickElement(el, label='버튼') {
    if (!el) throw new Error(`${label}을 찾지 못했습니다.`);
    try { el.scrollIntoView({block:'center', inline:'nearest'}); } catch {}
    await sleep(120);

    const rect = el.getBoundingClientRect();
    if (!rect.width || !rect.height) throw new Error(`${label} 화면 좌표를 확인하지 못했습니다.`);

    await sendRuntimeMessage({
      type:'EIMS_TRUSTED_CLICK',
      x: rect.left + rect.width/2,
      y: rect.top + rect.height/2
    });
    await sleep(350);
  }

  async function waitAndConfirmMessage(messageNeedle, timeout=8000) {
    const start=Date.now();
    while (Date.now()-start < timeout) {
      const btn = findVisibleConfirmButton(messageNeedle);
      if (btn) {
        // v20: 저장 확인/처리완료 팝업은 debugger 기반 실제 마우스 이벤트 대신
        // 이전의 DOM/synthetic 클릭 방식으로 되돌린다.
        // 사용자 테스트에서 실제 마우스 방식은 팝업 확인 버튼에서 실패했다.
        try {
          clickLikeUser(btn);
        } catch {
          try { btn.click(); } catch {}
        }
        await sleep(500);

        // 버튼이 사라졌거나 해당 메시지가 더 이상 보이지 않으면 성공으로 판단
        if (!isVisibleElement(btn)) return true;
        const text = (document.body?.textContent || '').replace(/\s+/g,' ');
        if (!text.includes(messageNeedle)) return true;

        // 한 번 더 native click() 시도
        try { btn.click(); } catch {}
        await sleep(400);
        if (!isVisibleElement(btn)) return true;
      }
      await sleep(150);
    }
    return false;
  }

  async function clickSaveButtonOnce() {
    const save = $(IDS.save);
    if (!save) throw new Error('[저장] 버튼을 찾지 못했습니다.');

    try { save.scrollIntoView({block:'center', inline:'nearest'}); } catch {}
    await sleep(180);

    const rect = save.getBoundingClientRect();
    if (!rect.width || !rect.height) {
      throw new Error('[저장] 버튼의 화면 좌표를 확인하지 못했습니다.');
    }

    const x = rect.left + rect.width / 2;
    const y = rect.top + rect.height / 2;

    status('저장 및 EIMS 확인창을 자동 처리합니다...');

    const res = await sendRuntimeMessage({
      type: 'EIMS_SAVE_WITH_NATIVE_DIALOGS',
      x, y
    });

    if (res.confirmHandled && res.processedHandled) {
      status('저장 확인 및 처리완료 창을 자동으로 확인했습니다.');
    } else if (res.confirmHandled) {
      status("'저장하시겠습니까?'는 자동 확인했습니다. 처리완료 창은 필요 시 직접 확인해 주세요.");
    } else {
      status("'저장하시겠습니까?' 자동 확인에 실패했습니다. 직접 [확인]을 눌러 주세요.", false);
    }

    return res;
  }

  async function refreshVehicleAndVerifySavedRow(vehicleNo, snapshot, beforeCounts) {
    status('저장 결과 확인을 위해 목록을 다시 조회합니다...');

    // 전체 차량 목록 재조회
    const search = $(IDS.search);
    if (search) {
      clickLikeUser(search);
      await waitLoadingGone(12000);
      await sleep(600);
    }

    // 같은 차량 다시 선택
    const vehicleCell = await waitFor(() => findVehicleCell(vehicleNo), 6000);
    if (vehicleCell) {
      clickLikeUser(vehicleCell);
      await sleep(700);
      await waitLoadingGone(6000);
    }

    // 우측 운행내역 grid가 갱신된 뒤 저장값 확인
    const found = findNewMatchingSavedRow(snapshot, beforeCounts);
    return found || null;
  }

  async function closeDispatchPopupIfOpen() {
    const closeBtn = document.getElementById(IDS.dispatchClose);
    if (closeBtn && visible(closeBtn)) {
      clickLikeUser(closeBtn);
      await sleep(250);
    }
  }

  function loadRecentEtcBusins() {
    try {
      return JSON.parse(localStorage.getItem(ETC_RECENT_KEY) || '{}') || {};
    } catch {
      return {};
    }
  }

  function saveRecentEtcBusins(opType, value) {
    try {
      const data = loadRecentEtcBusins();
      data[opType] = value;
      localStorage.setItem(ETC_RECENT_KEY, JSON.stringify(data));
    } catch {}
  }

  async function chooseEtcBusins(opType) {
    const options = ETC_BUSINS[opType] || [];
    if (!options.length) return '';

    if (options.length === 1) {
      saveRecentEtcBusins(opType, options[0]);
      return options[0];
    }

    const recent = loadRecentEtcBusins()[opType];
    const defaultValue = options.includes(recent) ? recent : options[0];

    return modal('운행내용 선택', ({box, close}) => {
      box.insertAdjacentHTML('beforeend', `
        <div style="margin-bottom:10px">
          <b>${opType}</b> 운행내용을 선택해 주세요.<br>
          30초 안에 선택하지 않으면 현재 선택값이 자동 입력됩니다.
        </div>
        <div id="eims-etc-options"></div>
        <div style="margin-top:12px;padding:10px;background:#eff6ff;border:1px solid #93c5fd;border-radius:6px">
          <div style="display:flex;align-items:center;gap:8px">
            <b>남은 시간: <span id="eims-etc-sec">30</span>초</b>
            <div id="eims-etc-extend" role="button" tabindex="0"
                 style="padding:4px 8px;background:#fff;border:1px solid #60a5fa;border-radius:4px;
                        cursor:pointer;font-weight:700;color:#1d4ed8">시간 연장</div>
          </div>
        </div>
        <div style="display:flex;justify-content:center;gap:12px;margin-top:14px;padding-top:12px;border-top:1px solid #ddd">
          <div id="eims-etc-apply" role="button" tabindex="0"
               style="min-width:82px;padding:9px 18px;background:#222;color:#fff;font-size:14px;font-weight:700;
                      text-align:center;border-radius:5px;cursor:pointer;line-height:20px">적용</div>
          <div id="eims-etc-cancel" role="button" tabindex="0"
               style="min-width:82px;padding:9px 18px;background:#555;color:#fff;font-size:14px;font-weight:700;
                      text-align:center;border-radius:5px;cursor:pointer;line-height:20px">취소</div>
        </div>
      `);

      const list = box.querySelector('#eims-etc-options');
      options.forEach((value, i) => {
        const label = document.createElement('label');
        label.style.cssText = 'display:block;margin:7px 0;padding:9px;border:1px solid #ccc;border-radius:6px;cursor:pointer;background:#fff;';
        label.innerHTML = `
          <input type="radio" name="eims-etc-radio" value="${value.replace(/"/g, '&quot;')}" ${value === defaultValue ? 'checked' : ''}>
          <span style="margin-left:7px">${value}</span>
          ${value === recent ? '<span style="float:right;color:#2563eb;font-size:12px">최근 선택</span>' : ''}
        `;
        list.appendChild(label);
      });

      let remaining = 30;
      let finished = false;

      const selectedValue = () =>
        box.querySelector('input[name="eims-etc-radio"]:checked')?.value || defaultValue;

      const finish = value => {
        if (finished) return;
        finished = true;
        clearInterval(timer);
        if (value) saveRecentEtcBusins(opType, value);
        close(value);
      };

      const timer = setInterval(() => {
        if (finished) return;
        remaining--;
        const sec = box.querySelector('#eims-etc-sec');
        if (sec) sec.textContent = remaining;
        if (remaining <= 0) {
          finish(selectedValue());
        }
      }, 1000);

      const apply = box.querySelector('#eims-etc-apply');
      const cancel = box.querySelector('#eims-etc-cancel');
      const extend = box.querySelector('#eims-etc-extend');

      const extendTime = () => {
        remaining += 60;
        const sec = box.querySelector('#eims-etc-sec');
        if (sec) sec.textContent = remaining;
      };
      extend.onclick = extendTime;
      extend.onkeydown = e => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          extendTime();
        }
      };

      apply.onclick = () => finish(selectedValue());
      apply.onkeydown = e => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          finish(selectedValue());
        }
      };

      cancel.onclick = () => {
        if (finished) return;
        finished = true;
        clearInterval(timer);
        close(null);
      };
      cancel.onkeydown = e => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          cancel.onclick();
        }
      };
    }, 500);
  }

  async function selectOperation(type) {
    const idx=OP[type];
    if (idx === undefined) throw new Error('운행구분을 선택해 주세요.');

    const id=`mf_tcMain_contents_tab_103002001_body_opratSeCode_input_${idx}`;
    const input=document.getElementById(id);
    const label=document.querySelector(`label[for="${id}"]`);

    if (!input && !label) throw new Error(`운행구분 '${type}' 요소를 찾지 못했습니다.`);

    // WebSquare는 label의 사용자 클릭 이벤트에서 내부 데이터 모델을 갱신할 수 있으므로
    // 직접 checked를 바꾸는 것보다 label 클릭을 우선한다.
    if (label) clickLikeUser(label);
    else clickLikeUser(input);

    await sleep(250);

    // 실제 checked 상태가 아니면 한 번 더 입력 요소를 클릭한다.
    if (input && !input.checked) {
      clickLikeUser(input);
      await sleep(200);
    }

    if (input && !input.checked) {
      throw new Error(`운행구분 '${type}' 선택이 실제 라디오 버튼에 반영되지 않았습니다.`);
    }

    // change/blur까지 전달해 WebSquare 바인딩을 확정
    if (input) {
      try { input.dispatchEvent(new Event('input',{bubbles:true})); } catch {}
      try { input.dispatchEvent(new Event('change',{bubbles:true})); } catch {}
      try { input.blur?.(); } catch {}
    }
    return true;
  }

  function exactVisibleTextElements(text) {
    const all = [...document.querySelectorAll('a,button,span,div,td,li,label')];
    return all.filter(el => {
      if (el.closest('#eims-vlog-panel')) return false;
      if (!visible(el)) return false;
      return (el.textContent || '').replace(/\s+/g,' ').trim() === text;
    });
  }

  function bestClickableByText(text) {
    const els = exactVisibleTextElements(text);
    if (!els.length) return null;

    const clickable = [];
    for (const el of els) {
      const a = el.closest('a,button');
      if (a && !a.closest('#eims-vlog-panel') && visible(a)) clickable.push(a);
    }
    const pool = clickable.length ? [...new Set(clickable)] : els;
    pool.sort((a,b) => {
      const ra=a.getBoundingClientRect(), rb=b.getBoundingClientRect();
      return (ra.width*ra.height) - (rb.width*rb.height);
    });
    return pool[0] || null;
  }

  async function clickMenuText(text, timeout=7000) {
    const el = await waitFor(() => bestClickableByText(text), timeout);
    if (!el) return false;
    clickLikeUser(el);
    await sleep(450);
    await waitLoadingGone(8000);
    return true;
  }

  function findTreeRowByExactText(text) {
    const labels = [...document.querySelectorAll('.w2treeview_label, span, td, div')]
      .filter(el => visible(el) && (el.textContent || '').replace(/\s+/g,' ').trim() === text);

    for (const label of labels) {
      let p = label;
      for (let i=0; i<7 && p; i++, p=p.parentElement) {
        if (p.querySelector?.('.w2treeview_icon_navi')) {
          return {row:p, label, icon:p.querySelector('.w2treeview_icon_navi')};
        }
      }
    }
    return null;
  }

  async function openDrivingLogTree() {
    // 사용자 제공 구조:
    // 운행일지 펼침 아이콘 = <div class="w2treeview_icon_navi"></div>
    const found = await waitFor(() => findTreeRowByExactText('운행일지'), 7000);

    if (!found) {
      // 텍스트 노드를 못 찾은 경우, 왼쪽 메뉴에서 '운행일지'가 보이는 행을 다시 탐색
      const candidates = [...document.querySelectorAll('.w2treeview_icon_navi')].filter(visible);
      for (const icon of candidates) {
        const row = icon.parentElement?.parentElement || icon.parentElement;
        const txt = (row?.textContent || '').replace(/\s+/g,' ').trim();
        if (txt.includes('운행일지')) {
          clickLikeUser(icon);
          await sleep(500);
          return true;
        }
      }
      return false;
    }

    // 차량운행일지 하위메뉴가 이미 보이면 펼침 생략
    if (visible(document.getElementById('mf_tvLeftMenu_label_13'))) return true;

    clickLikeUser(found.icon);
    await sleep(500);

    // 트리 아이콘 클릭이 반영되지 않으면 행/라벨 클릭도 1회 보조
    if (!visible(document.getElementById('mf_tvLeftMenu_label_13'))) {
      clickLikeUser(found.label);
      await sleep(450);
    }

    return !!document.getElementById('mf_tvLeftMenu_label_13');
  }

  async function clickVehicleDrivingLogMenu() {
    // 사용자 제공 정확한 요소
    // <span id="mf_tvLeftMenu_label_13" class="w2treeview_label">차량운행일지</span>
    const label = await waitFor(
      () => {
        const el = document.getElementById('mf_tvLeftMenu_label_13');
        return el && visible(el) ? el : null;
      },
      7000
    );

    if (!label) return false;

    // WebSquare treeview는 label 자신 또는 상위 clickable node가 이벤트를 가질 수 있어 둘 다 대응
    const clickable = label.closest('a,td,div') || label;
    clickLikeUser(clickable);
    await sleep(400);

    if (!$(IDS.search)) {
      clickLikeUser(label);
      await sleep(500);
    }

    await waitLoadingGone(10000);
    return true;
  }

  async function ensureVehicleLogPage() {
    if ($(IDS.search) && $(IDS.addRow)) return true;

    status('운영점검 → 운행일지 → 차량운행일지 화면으로 이동합니다...');

    // 상단 운영점검은 현재 이미 선택돼 있어도 문제 없도록 처리
    const topOperation = bestClickableByText('운영점검');
    if (topOperation) {
      clickLikeUser(topOperation);
      await sleep(350);
    }

    // 운행일지 트리 펼치기
    const opened = await openDrivingLogTree();
    if (!opened) {
      throw new Error("'운행일지' 트리 메뉴를 펼치지 못했습니다.");
    }

    // 정확한 ID로 차량운행일지 선택
    const clicked = await clickVehicleDrivingLogMenu();
    if (!clicked) {
      throw new Error("하위 메뉴 '차량운행일지'(mf_tvLeftMenu_label_13)를 찾지 못했습니다.");
    }

    const ready = await waitFor(() => $(IDS.search), 12000);
    if (!ready) {
      throw new Error("차량운행일지 화면 진입 후 [검색] 버튼이 나타나지 않았습니다.");
    }

    await waitLoadingGone(12000);
    await sleep(500);
    status('차량운행일지 화면 진입 완료.');
    return true;
  }

  async function setVehicleEquipmentType(vehicleNo) {
    const target = vehicleNo==='47모9366' ? '행정지원차' : '소방자동차';
    const norm = v => (v||'').replace(/\s+/g,' ').trim();

    // WebSquare의 wq_uuid_* 값은 화면 구성 때마다 달라질 수 있으므로
    // v47부터 특정 UUID를 고정해서 찾지 않는다.
    const findSecondLabel = () => {
      const candidates=[...document.querySelectorAll(
        'div[id$="_selEqpnmDivTwo_label"], span[id$="_selEqpnmDivTwo_label"], [id*="_selEqpnmDivTwo_label"]'
      )].filter(el => visible(el) && !el.closest('#eims-vlog-panel'));

      // 현재 값이 목표값이면 최우선.
      const exact=candidates.find(el=>norm(el.textContent)===target);
      if(exact) return exact;

      // 장비분류 영역은 화면 상단에 있으므로 보이는 후보 중 위쪽 것을 우선.
      candidates.sort((a,b)=>{
        const ra=a.getBoundingClientRect(), rb=b.getBoundingClientRect();
        return ra.top-rb.top || ra.left-rb.left;
      });
      return candidates[0]||null;
    };

    const label=await waitFor(findSecondLabel,7000);
    if(!label) throw new Error('장비분류 2차 선택상자를 찾지 못했습니다.');

    if(norm(label.textContent)===target) return true;

    status(`장비분류를 '${target}'로 변경합니다...`);
    clickLikeUser(label);
    await sleep(350);

    const option=await waitFor(()=>{
      const candidates=[...document.querySelectorAll(
        'td[role="listitem"], td[role="option"], [role="listitem"], [role="option"], .w2selectbox_item, .w2selectbox_item_nobg'
      )].filter(el=>{
        if(!visible(el)) return false;
        if(el.closest('#eims-vlog-panel')) return false;
        return norm(el.textContent)===target;
      });

      // 같은 이름이 여럿이면 현재 선택상자와 가장 가까운 옵션을 우선한다.
      const lr=label.getBoundingClientRect();
      candidates.sort((a,b)=>{
        const ra=a.getBoundingClientRect(), rb=b.getBoundingClientRect();
        const da=Math.abs(ra.left-lr.left)+Math.abs(ra.top-lr.bottom);
        const db=Math.abs(rb.left-lr.left)+Math.abs(rb.top-lr.bottom);
        return da-db;
      });
      return candidates[0]||null;
    },5000);

    if(!option){
      throw new Error(`장비분류 목록에서 '${target}' 항목을 찾지 못했습니다.`);
    }

    try{ option.scrollIntoView({block:'nearest',inline:'nearest'}); }catch{}

    // WebSquare가 요구하는 일반 DOM 마우스 이벤트 순서
    for(const type of ['mouseover','mousedown','mouseup','click']){
      try{
        option.dispatchEvent(new MouseEvent(type,{
          bubbles:true,cancelable:true,view:window,button:0
        }));
      }catch{}
    }

    await sleep(700);
    await waitLoadingGone(8000);

    let changed=await waitFor(()=>{
      const current=findSecondLabel();
      return current && norm(current.textContent)===target;
    },3500);

    if(!changed){
      try{ option.click(); }catch{}
      await sleep(600);
      changed=await waitFor(()=>{
        const current=findSecondLabel();
        return current && norm(current.textContent)===target;
      },2500);
    }

    if(!changed){
      throw new Error(`장비분류 '${target}' 선택이 반영되지 않았습니다.`);
    }

    return true;
  }

  async function run() {
    const vehicleNo=document.getElementById('eims-vlog-vehicle')?.value.trim();
    const op=document.getElementById('eims-vlog-op')?.value;
    const destFallback=document.getElementById('eims-vlog-dest')?.value.trim();
    const autoSave=document.getElementById('eims-vlog-autosave')?.checked;
    if (!vehicleNo) { alert('차량번호를 입력해 주세요.'); return; }

    try {
      await ensureVehicleLogPage();

      // v46: 현재 검색결과에 대상 차량이 이미 보이면
      // 장비분류 재선택/검색 없이 그 행을 그대로 사용한다.
      let vehicle = findVehicleCell(vehicleNo);

      if (vehicle) {
        status(`현재 차량목록에서 ${vehicleNo} 차량을 확인했습니다. 기존 검색결과를 사용합니다.`);
      } else {
        // 현재 표에 차량이 없을 때만 기존 장비분류 선택 + 검색 수행
        await setVehicleEquipmentType(vehicleNo);

        status('검색 버튼을 누르는 중...');
        const search=$(IDS.search);
        if (!search) throw new Error('차량운행일지의 [검색] 버튼을 찾지 못했습니다.');
        clickLikeUser(search);
        await waitLoadingGone();
        await sleep(400);

        status(`차량 ${vehicleNo} 찾는 중...`);
        vehicle = await waitFor(()=>findVehicleCell(vehicleNo), 6000);
      }

      if (!vehicle) throw new Error(`차량목록에서 '${vehicleNo}' 차량을 찾지 못했습니다.`);
      clickLikeUser(vehicle);
      await sleep(500);

      const savedRowsBefore = operationSignatureCounts();

      status('행추가...');
      const add=$(IDS.addRow);
      if (!add) throw new Error('[행추가] 버튼을 찾지 못했습니다.');
      clickLikeUser(add);
      await sleep(700);

      status('출동정보를 조회하는 중...');
      const dispatch=$(IDS.dispatch);
      if (!dispatch) throw new Error('[출동정보조회] 버튼을 찾지 못했습니다.');
      clickLikeUser(dispatch);
      await sleep(700);
      await waitLoadingGone();
      await sleep(400);

      let matches = dispatchRowsForVehicle(vehicleNo);
      let usedDispatch=false;
      if (matches.length) {
        const chosen=await chooseDispatch(matches);
        if (chosen) {
          status('선택한 출동정보를 반영하는 중...');
          clickLikeUser(chosen, true);
          await sleep(900);
          usedDispatch=true;
        }
      }

      if (!usedDispatch) {
        status('일치하는 출동정보 없음 → 수동 운행시간 입력');
        await closeDispatchPopupIfOpen();
        const t=await manualTimeDialog();
        if (!t) throw new Error('수동 운행시간 입력이 취소되었습니다.');
        status('수동 운행시간을 EIMS 형식으로 확정하는 중...');
        await commitManualDateTimeFields(t);
      }

      status(`운행구분 '${op}' 선택`);
      await selectOperation(op);
      await sleep(350);

      // 시동점검을 선택하면 EIMS가 목적지에 '시동점검'을 자동 입력하므로,
      // 자동화 패널의 '수동 입력 시 목적지' 값으로 다시 덮어쓴다.
      const dst = $(IDS.destination);
      if (op === '시동점검' && dst && destFallback) {
        await sleep(500);
        setValue(dst,'');
        await sleep(100);
        try { await typeLikeUser(dst,destFallback,'목적지'); }
        catch { await setValueVerified(dst,destFallback,'목적지'); }
        await sleep(400);
        if(String(dst.value||'').trim()!==destFallback.trim()){
          setValue(dst,''); await sleep(100);
          try { await typeLikeUser(dst,destFallback,'목적지'); }
          catch { await setValueVerified(dst,destFallback,'목적지'); }
        }
      } else if (!usedDispatch && destFallback) {
        if (dst && !String(dst.value||'').trim()) {
          try { await typeLikeUser(dst,destFallback,'목적지'); }
          catch { await setValueVerified(dst,destFallback,'목적지'); }
        }
      }

      status('운행내용 입력...');
      const etcValue = await chooseEtcBusins(op);
      if (etcValue === null) {
        status('운행내용 선택이 취소되어 자동화를 중단했습니다.', false);
        return;
      }
      const etcInput = $(IDS.etcBusins);
      if (!etcInput) throw new Error('운행내용 입력칸을 찾지 못했습니다.');
      await setValueVerified(etcInput,etcValue,'운행내용');
      await sleep(150);

      status('운행거리 입력 대기...');
      const dist=await distanceDialog();
      if (!dist) {
        status('운행거리 입력이 취소되어 자동화를 중단했습니다.', false);
        return;
      }
      if (dist.type==='current') {
        const currentEl = $(IDS.currentDistance);
        if (!currentEl) throw new Error('운행거리(금회) 입력칸을 찾지 못했습니다.');

        // 0km 포함 금회 운행거리는 화면 표시뿐 아니라 WebSquare 내부값까지 확정.
        try { await typeLikeUser(currentEl, dist.value, '운행거리(금회)'); }
        catch { await setValueVerified(currentEl, dist.value, '운행거리(금회)'); }

        try { currentEl.dispatchEvent(new Event('change',{bubbles:true,cancelable:true})); } catch {}
        try { currentEl.blur?.(); } catch {}
        try { $(IDS.destination)?.focus?.(); } catch {}

        // v34에서 확인 alert를 없앤 뒤 즉시 저장으로 넘어가며 0km가 commit되지 않는 현상 방지.
        await sleep(Number(dist.value) === 0 ? 650 : 250);

        // 운행거리(금회)=0이면 차량 계기판 운행거리 값을 완전히 비운다.
        if (Number(dist.value) === 0) {
          const meterEl = $(IDS.meter);
          if (meterEl) {
            try {
              meterEl.focus?.();
              meterEl.value = '';
              meterEl.setAttribute('value','');
              meterEl.dispatchEvent(new Event('input',{bubbles:true,cancelable:true}));
              meterEl.dispatchEvent(new Event('change',{bubbles:true,cancelable:true}));
              meterEl.blur?.();
            } catch {}
            await sleep(180);
          }
        }
      } else {
        const meterEl = $(IDS.meter);
        if (!meterEl) throw new Error('차량 계기판 운행거리 입력칸을 찾지 못했습니다.');
        try { await typeLikeUser(meterEl, dist.value, '차량 계기판 운행거리'); }
        catch { await setValueVerified(meterEl, dist.value, '차량 계기판 운행거리'); }
        try { meterEl.blur?.(); } catch {}
        await sleep(500); // EIMS 자체 계산 반영 대기
      }

      // v4: 운행거리 입력 완료 또는 60초 타임아웃(금회=0) 후
      // 출동정보조회 창이 남아 있으면 자동으로 닫는다.
      await closeDispatchPopupIfOpen();

      // 최종 저장 직전 금회거리 0이면 차량 계기판 운행거리를 다시 비워둔다.
      const currentDistBeforeSave = String($(IDS.currentDistance)?.value || '').replace(/,/g,'').trim();
      if (currentDistBeforeSave === '0') {
        const meterBeforeSave = $(IDS.meter);
        if (meterBeforeSave) {
          try {
            meterBeforeSave.value='';
            meterBeforeSave.setAttribute('value','');
            meterBeforeSave.dispatchEvent(new Event('input',{bubbles:true,cancelable:true}));
            meterBeforeSave.dispatchEvent(new Event('change',{bubbles:true,cancelable:true}));
            meterBeforeSave.blur?.();
          } catch {}
        }
      }

      const finalSnapshot = currentFormSnapshot(op);
      await forceCommitInputs();
      assertCommittedTimeFormatBeforeSave();

      if (autoSave) {
        status('저장 버튼을 실제 마우스 입력 방식으로 1회 실행합니다...');
        await clickSaveButtonOnce();

        // EIMS의 저장 확인 팝업은 사용자가 직접 확인할 수 있다.
        // 확인 후 실제 우측 운행내역 Grid에 새 행이 생겨야 성공으로 처리한다.
        // v25: 저장 검증 허용 시간을 총 약 10초로 확대.
        // 현재 Grid 최대 5초 → 목록 재조회 1회 → 추가 최대 5초 확인.
        let savedRow = await waitForSavedRow(finalSnapshot, savedRowsBefore, 5000);

        if (!savedRow) {
          status('저장된 운행내역을 다시 조회합니다...');
          savedRow = await refreshVehicleAndVerifySavedRow(vehicleNo, finalSnapshot, savedRowsBefore);
        }

        if (!savedRow) {
          const deadline = Date.now() + 5000;
          while (!savedRow && Date.now() < deadline) {
            await sleep(400);
            savedRow = findNewMatchingSavedRow(finalSnapshot, savedRowsBefore);
          }
        }

        if (!savedRow) {
          status('저장 후 약 10초 동안 실제 운행내역을 확인하지 못했습니다.', false);
          alert('[EIMS 차량운행일지 자동화]\n저장 후 약 10초 동안 실제 운행내역을 확인하지 못했습니다.\n\n통계에는 추가하지 않았습니다.');
          return;
        }

        status('실제 운행내역 저장을 확인했습니다. 통계에 반영합니다.');
        recordCompletedEntry(op,{
          vehicle:vehicleNo,
          destination:finalSnapshot.destination,
          etc:finalSnapshot.etc,
          begin:`${finalSnapshot.date} ${finalSnapshot.begin}`.trim(),
          end:`${normalizeDateText($(IDS.endDate)?.value)} ${finalSnapshot.end}`.trim(),
          distance:finalSnapshot.distance
        });
      } else {
        status('입력 완료. 내용을 확인한 뒤 EIMS [저장] 버튼을 눌러 주세요. 통계는 실제 저장 확인 후에만 집계됩니다.');
      }
    } catch(e) {
      console.error(e);
      status(`오류: ${e.message}`, false);
      alert(`[EIMS 차량운행일지 자동화]\n${e.message}`);
    }
  }

  const PANEL_HIDE_KEY = 'eimsVehicleLogHideUntilV7';
  const PANEL_HIDE_EPOCH_KEY = 'eimsVehicleLogHideEpochV7';

  function getExtensionEpoch() {
    return new Promise(resolve => {
      try {
        chrome.runtime.sendMessage({type:'EIMS_GET_EXTENSION_EPOCH'}, res => {
          if (chrome.runtime.lastError || !res?.ok || !res.epoch) {
            resolve(null);
            return;
          }
          resolve(res.epoch);
        });
      } catch {
        resolve(null);
      }
    });
  }

  async function panelHiddenFor24h() {
    const until = Number(localStorage.getItem(PANEL_HIDE_KEY) || 0);
    const savedEpoch = localStorage.getItem(PANEL_HIDE_EPOCH_KEY) || '';
    const currentEpoch = await getExtensionEpoch();

    // If extension epoch cannot be verified, fail open: show panel.
    if (!currentEpoch || !savedEpoch || savedEpoch !== currentEpoch) {
      localStorage.removeItem(PANEL_HIDE_KEY);
      localStorage.removeItem(PANEL_HIDE_EPOCH_KEY);
      return false;
    }
    return Number.isFinite(until) && until > Date.now();
  }

  async function hidePanelFor24h(panel) {
    const epoch = await getExtensionEpoch();
    if (!epoch) {
      // Cannot safely persist suppression without a verifiable extension epoch.
      panel.remove();
      return;
    }
    localStorage.setItem(PANEL_HIDE_KEY, String(Date.now() + 24*60*60*1000));
    localStorage.setItem(PANEL_HIDE_EPOCH_KEY, epoch);
    panel.remove();
  }

  const STATS_KEY = 'eimsVehicleLogDailyStatsV8';

  function localDateKey(date=new Date()) {
    const p = n => String(n).padStart(2,'0');
    return `${date.getFullYear()}-${p(date.getMonth()+1)}-${p(date.getDate())}`;
  }

  // 통계 합산 구간: 08:40부터 다음 날 09:00까지.
  // 00:00~08:39에는 전날 08:40에 시작한 구간을 현재 통계 구간으로 본다.
  function statsPeriod(now=new Date()) {
    const start = new Date(now);
    start.setSeconds(0,0);

    const minuteOfDay = now.getHours()*60 + now.getMinutes();
    const startMinute = 8*60 + 40;

    if (minuteOfDay >= startMinute) {
      start.setHours(8,40,0,0);
    } else {
      start.setDate(start.getDate()-1);
      start.setHours(8,40,0,0);
    }

    const end = new Date(start);
    end.setDate(end.getDate()+1);
    end.setHours(9,0,0,0);

    const key = `${localDateKey(start)}T08:40`;
    return {key,start,end};
  }

  function statsPeriodLabel() {
    const {start,end}=statsPeriod();
    return `${start.getMonth()+1}/${start.getDate()} 08:40 ~ ${end.getMonth()+1}/${end.getDate()} 09:00`;
  }

  function parseStatsDateTime(value) {
    const v=String(value||'').trim();
    if(!v) return null;

    // 2026-08-21 12:34 / 20260821 1234 / 20260821 12:34 모두 지원
    const digits=v.replace(/\D/g,'');
    if(digits.length < 12) return null;

    const y=Number(digits.slice(0,4));
    const mo=Number(digits.slice(4,6));
    const d=Number(digits.slice(6,8));
    const h=Number(digits.slice(8,10));
    const mi=Number(digits.slice(10,12));
    const dt=new Date(y,mo-1,d,h,mi,0,0);
    return Number.isNaN(dt.getTime()) ? null : dt;
  }

  function recordDrivingDate(r) {
    return parseStatsDateTime(r?.begin) || new Date(Number(r?.createdAt)||0);
  }

  function recordInCurrentStatsPeriod(r) {
    const dt=recordDrivingDate(r);
    if(!dt || Number.isNaN(dt.getTime())) return false;
    const {start,end}=statsPeriod();
    return dt>=start && dt<=end;
  }

  function emptyStats() {
    const p=statsPeriod();
    return {periodKey:p.key, records:[]};
  }

  function loadStats() {
    try {
      const raw=JSON.parse(localStorage.getItem(STATS_KEY)||'null');
      const p=statsPeriod();

      if(!raw || !Array.isArray(raw.records)) {
        const fresh=emptyStats();
        localStorage.setItem(STATS_KEY,JSON.stringify(fresh));
        return fresh;
      }

      // v37 이하(date 기반) 자료도 현재 근무 통계구간에 해당하는 기록은 보존.
      const records=raw.records.filter(recordInCurrentStatsPeriod);
      const normalized={periodKey:p.key,records};

      if(raw.periodKey!==p.key || raw.records.length!==records.length) {
        localStorage.setItem(STATS_KEY,JSON.stringify(normalized));
      }
      return normalized;
    } catch {
      return emptyStats();
    }
  }

  function saveStats(x) {
    try {
      x.periodKey=statsPeriod().key;
      x.records=(x.records||[]).filter(recordInCurrentStatsPeriod);
      localStorage.setItem(STATS_KEY,JSON.stringify(x));
    } catch {}
  }

  function makeStatSourceKey(detail={}) {
    return [
      detail.vehicle||'',
      detail.begin||'',
      detail.end||'',
      detail.op||'',
      detail.etc||'',
      detail.destination||'',
      String(detail.distance??'')
    ].join('|');
  }

  function recordCompletedEntry(op,detail={}) {
    const record={
      id:`${Date.now()}-${Math.random()}`,
      createdAt:Date.now(),
      op,
      vehicle:detail.vehicle||'',
      vehicleName:VEHICLES[detail.vehicle]||'',
      destination:detail.destination||'',
      etc:detail.etc||'',
      begin:detail.begin||'',
      end:detail.end||'',
      distance:detail.distance||'',
      source:detail.source||'auto',
      sourceKey:detail.sourceKey||makeStatSourceKey({...detail,op})
    };

    // 운행시간이 현재 08:40~익일09:00 통계 구간 밖이면 집계하지 않는다.
    if(!recordInCurrentStatsPeriod(record)) return false;

    const x=loadStats();
    if(record.sourceKey && x.records.some(r=>r.sourceKey===record.sourceKey)) return false;

    x.records.push(record);
    saveStats(x);
    renderStats();
    return true;
  }

  function removeLatestMatchingStat(vehicle, op) {
    const x=loadStats();
    for(let i=x.records.length-1;i>=0;i--){
      const r=x.records[i];
      if((!vehicle||r.vehicle===vehicle)&&(!op||r.op===op)){
        const removed=x.records.splice(i,1)[0];
        saveStats(x); renderStats(); return removed;
      }
    }
    return null;
  }

  function showStatsDetail(cat){
    const x=loadStats(), rows=cat==='총 입력'?x.records:x.records.filter(r=>r.op===cat);

    modal(`${cat} 입력내역`,({box,close})=>{
      const title=box.firstElementChild;
      if(title){
        title.style.cssText += ';cursor:move;user-select:none;padding-bottom:8px;border-bottom:1px solid #ddd;';
        title.title='드래그해서 창 이동';
      }

      const list=document.createElement('div');
      list.id='eims-stats-detail-list';
      box.appendChild(list);

      const renderDetail=()=>{
        const data=loadStats();
        const currentRows=cat==='총 입력'?data.records:data.records.filter(r=>r.op===cat);
        list.innerHTML='';

        if(!currentRows.length){
          list.innerHTML='<div style="padding:12px 0">입력 내역이 없습니다.</div>';
          return;
        }

        currentRows.slice().reverse().forEach(r=>{
          const item=document.createElement('div');
          item.style.cssText='position:relative;padding:10px 34px 10px 0;border-bottom:1px solid #ddd';

          const beginRaw=String(r.begin||'').trim();
          const endRaw=String(r.end||'').trim();

          const timeOnly=v=>{
            if(!v)return '';
            const m=v.match(/(\d{1,2}):(\d{2})$/);
            if(m)return `${m[1].padStart(2,'0')}:${m[2]}`;
            const digits=v.replace(/\D/g,'');
            if(digits.length>=4){
              const t=digits.slice(-4);
              return `${t.slice(0,2)}:${t.slice(2)}`;
            }
            return v;
          };

          const beginTime=timeOnly(beginRaw);
          const endTime=timeOnly(endRaw);
          const drivingTime=(beginTime||endTime) ? `${beginTime||'-'} ~ ${endTime||'-'}` : '';

          item.innerHTML=`
            <div><b>${r.vehicle}${r.vehicleName?` (${r.vehicleName})`:''}</b> · ${r.op}${r.etc?` · ${r.etc}`:''}</div>
            ${drivingTime?`<div style="font-size:12px;color:#374151;margin-top:3px"><b>운행시간</b> ${drivingTime}</div>`:''}
            <div style="font-size:12px;color:#555;margin-top:3px">${r.destination||''}${r.distance!==''&&r.distance!=null?` · ${r.distance}km`:''}</div>
            <button type="button" class="eims-stat-delete" title="이 내역 삭제"
                    style="position:absolute;right:0;top:10px;width:24px;height:24px;border:none;
                           background:transparent;border-radius:0;cursor:pointer;font-size:18px;font-weight:700;
                           line-height:24px;text-align:center;padding:0;color:#444">✕</button>`;

          item.querySelector('.eims-stat-delete').onclick=()=>{
            if(!confirm('삭제하시겠습니까?')) return;

            const latest=loadStats();
            const idx=latest.records.findIndex(v=>v.id===r.id);
            if(idx>=0){
              latest.records.splice(idx,1);
              saveStats(latest);
              renderStats();
              renderDetail();
            }
          };

          list.appendChild(item);
        });
      };

      renderDetail();

      const q=document.createElement('div');
      q.textContent='닫기';
      q.style.cssText='margin:12px auto 0;width:80px;padding:8px;background:#333;color:#fff;text-align:center;border-radius:5px;cursor:pointer';
      q.onclick=()=>close();
      box.appendChild(q);

      // 드래그 이동
      let dragging=false, offsetX=0, offsetY=0;
      if(title){
        title.addEventListener('mousedown',e=>{
          if(e.button!==0)return;
          const rect=box.getBoundingClientRect();
          dragging=true;
          offsetX=e.clientX-rect.left;
          offsetY=e.clientY-rect.top;
          box.style.position='fixed';
          box.style.left=rect.left+'px';
          box.style.top=rect.top+'px';
          box.style.margin='0';
          box.style.zIndex='2147483647';
          e.preventDefault();
        });
      }

      const onMove=e=>{
        if(!dragging)return;
        const maxX=Math.max(0,window.innerWidth-box.offsetWidth);
        const maxY=Math.max(0,window.innerHeight-box.offsetHeight);
        box.style.left=Math.min(maxX,Math.max(0,e.clientX-offsetX))+'px';
        box.style.top=Math.min(maxY,Math.max(0,e.clientY-offsetY))+'px';
      };
      const onUp=()=>{dragging=false;};

      document.addEventListener('mousemove',onMove);
      document.addEventListener('mouseup',onUp);

      q.onclick=()=>{
        document.removeEventListener('mousemove',onMove);
        document.removeEventListener('mouseup',onUp);
        close();
      };
    },560);
  }


  function showStatsGraph() {
    const data=loadStats();
    const cats=['화재','구조','구급','훈련','대민지원','기타','시동점검'];
    const colors={
      '화재':'#ef4444',
      '구조':'#f97316',
      '구급':'#3b82f6',
      '훈련':'#8b5cf6',
      '대민지원':'#14b8a6',
      '기타':'#6b7280',
      '시동점검':'#22c55e'
    };
    const counts=Object.fromEntries(cats.map(c=>[c,data.records.filter(r=>r.op===c).length]));
    const max=Math.max(1,...Object.values(counts));

    modal('차량운행일지 통계 그래프',({box,close})=>{
      box.style.width='620px';
      box.style.maxWidth='92vw';

      const title=box.firstElementChild;
      if(title){
        title.style.cssText += ';cursor:move;user-select:none;padding-bottom:8px;border-bottom:1px solid #ddd;';
        title.title='드래그해서 창 이동';
      }

      box.insertAdjacentHTML('beforeend',`
        <div style="font-size:12px;color:#555;margin:8px 0 14px">
          합산시간: ${statsPeriodLabel()} · 총 입력 ${data.records.length}건
        </div>
        <div id="eims-stats-chart" style="display:flex;align-items:flex-end;gap:12px;height:250px;padding:16px 8px 28px;border-left:1px solid #bbb;border-bottom:1px solid #bbb"></div>
      `);

      const chart=box.querySelector('#eims-stats-chart');
      cats.forEach(cat=>{
        const count=counts[cat];
        const wrap=document.createElement('div');
        wrap.style.cssText='flex:1;height:100%;display:flex;flex-direction:column;justify-content:flex-end;align-items:center;min-width:48px;';
        const barHeight=Math.max(count?14:2, Math.round((count/max)*185));
        wrap.innerHTML=`
          <div style="font-weight:700;font-size:12px;margin-bottom:5px">${count}건</div>
          <div title="${cat} ${count}건" style="width:70%;max-width:52px;height:${barHeight}px;background:${colors[cat]};border-radius:5px 5px 0 0"></div>
          <div style="font-size:11px;margin-top:7px;white-space:nowrap">${cat}</div>`;
        chart.appendChild(wrap);
      });

      const closeBtn=document.createElement('div');
      closeBtn.textContent='닫기';
      closeBtn.style.cssText='margin:18px auto 0;width:80px;padding:8px;background:#333;color:#fff;text-align:center;border-radius:5px;cursor:pointer';
      closeBtn.onclick=()=>close();
      box.appendChild(closeBtn);
    },620);
  }

  function operationRowDateTime(sig) {
    if(!sig?.date || !sig?.begin) return null;
    return parseStatsDateTime(`${sig.date} ${sig.begin}`);
  }

  function currentPanelVehicle() {
    return document.querySelector('#eims-vlog-vehicle')?.value || '';
  }

  function statKeyFromGridRow(vehicle,sig) {
    return makeStatSourceKey({
      vehicle,
      begin:`${sig.date} ${sig.begin}`,
      end:`${sig.date} ${sig.end}`,
      op:sig.op,
      etc:sig.etc,
      destination:sig.destination,
      distance:sig.distance
    });
  }

  async function showManualStatsImport() {
    try {
      await ensureVehicleLogPage();
    } catch(e) {
      alert(`[EIMS 차량운행일지 자동화]\n${e.message}`);
      return;
    }

    const vehicle=currentPanelVehicle();
    const now=Date.now();
    const cutoff=now-(24*60*60*1000);
    const stats=loadStats();
    const existingKeys=new Set(stats.records.map(r=>r.sourceKey).filter(Boolean));

    const rows=operationGridRows()
      .map(tr=>({tr,sig:operationRowSignature(tr)}))
      .filter(x=>{
        const dt=operationRowDateTime(x.sig);
        return dt && dt.getTime()>=cutoff && dt.getTime()<=now;
      })
      .sort((a,b)=>operationRowDateTime(b.sig)-operationRowDateTime(a.sig));

    modal('최근 24시간 차량운행일지 선택',({box,close})=>{
      box.style.width='920px';
      box.style.maxWidth='96vw';
      box.style.maxHeight='88vh';
      box.style.overflow='hidden';

      const title=box.firstElementChild;
      if(title){
        title.style.cssText += ';cursor:move;user-select:none;padding-bottom:8px;border-bottom:1px solid #ddd;';
        title.title='드래그해서 창 이동';
      }

      const {start,end}=statsPeriod();
      box.insertAdjacentHTML('beforeend',`
        <div style="font-size:12px;color:#555;margin:8px 0">
          최근 24시간 내 EIMS 운행내역입니다. 체크 후 <b>통계 반영</b>을 누르세요.<br>
          통계 합산 대상: ${statsPeriodLabel()} (이 시간 밖의 행은 선택할 수 없습니다.)
        </div>
        <div style="max-height:500px;overflow:auto;border:1px solid #ccc;border-radius:6px">
          <table style="width:100%;border-collapse:collapse;font-size:12px">
            <thead style="position:sticky;top:0;background:#f3f4f6;z-index:1">
              <tr>
                <th style="padding:7px;width:42px">선택</th>
                <th style="padding:7px">운행일자</th>
                <th style="padding:7px">운행시간</th>
                <th style="padding:7px">운행구분</th>
                <th style="padding:7px">운행내용</th>
                <th style="padding:7px">목적지</th>
                <th style="padding:7px">거리</th>
              </tr>
            </thead>
            <tbody id="eims-manual-stat-body"></tbody>
          </table>
        </div>
        <div style="display:flex;justify-content:center;gap:12px;margin-top:14px">
          <div id="eims-manual-stat-apply" style="padding:9px 18px;background:#222;color:#fff;border-radius:5px;cursor:pointer;font-weight:700">통계 반영</div>
          <div id="eims-manual-stat-cancel" style="padding:9px 18px;background:#555;color:#fff;border-radius:5px;cursor:pointer;font-weight:700">취소</div>
        </div>
      `);

      const tbody=box.querySelector('#eims-manual-stat-body');

      if(!rows.length){
        tbody.innerHTML='<tr><td colspan="7" style="padding:16px;text-align:center">현재 화면에서 최근 24시간 운행내역을 찾지 못했습니다.</td></tr>';
      }

      rows.forEach(({sig},idx)=>{
        const dt=operationRowDateTime(sig);
        const inPeriod=dt>=start && dt<=end;
        const key=statKeyFromGridRow(vehicle,sig);
        const already=existingKeys.has(key);

        const tr=document.createElement('tr');
        tr.style.cssText=`border-top:1px solid #eee;${(!inPeriod||already)?'opacity:.5;':''}`;
        tr.innerHTML=`
          <td style="padding:7px;text-align:center">
            <input type="checkbox" data-row-index="${idx}" ${(!inPeriod||already)?'disabled':''}
                   style="width:16px;height:16px;cursor:${(!inPeriod||already)?'not-allowed':'pointer'};pointer-events:auto">
          </td>
          <td style="padding:7px;text-align:center">${sig.date||''}</td>
          <td style="padding:7px;text-align:center">${sig.begin||''} ~ ${sig.end||''}</td>
          <td style="padding:7px;text-align:center">${sig.op||''}</td>
          <td style="padding:7px;text-align:center">${sig.etc||''}</td>
          <td style="padding:7px">${sig.destination||''}</td>
          <td style="padding:7px;text-align:right">${sig.distance||'0'} km ${already?'<span style="color:#2563eb">(반영됨)</span>':(!inPeriod?'<span style="color:#b45309">(합산시간 밖)</span>':'')}</td>`;
        tr.addEventListener('click', e=>{
          if(e.target.closest('input,button,a')) return;
          const cb=tr.querySelector('input[type="checkbox"]');
          if(cb && !cb.disabled) cb.checked=!cb.checked;
        });

        tbody.appendChild(tr);
      });

      box.querySelector('#eims-manual-stat-apply').onclick=()=>{
        const checked=[...box.querySelectorAll('#eims-manual-stat-body input[type="checkbox"]:checked')];
        if(!checked.length){
          alert('통계에 반영할 운행내역을 선택해 주세요.');
          return;
        }

        let added=0;
        checked.forEach(ch=>{
          const item=rows[Number(ch.dataset.rowIndex)];
          if(!item)return;
          const sig=item.sig;
          const key=statKeyFromGridRow(vehicle,sig);

          if(recordCompletedEntry(sig.op,{
            vehicle,
            destination:sig.destination,
            etc:sig.etc,
            begin:`${sig.date} ${sig.begin}`,
            end:`${sig.date} ${sig.end}`,
            distance:sig.distance,
            source:'manual-import',
            sourceKey:key
          })) added++;
        });

        alert(`${added}건을 차량운행일지 입력 통계에 반영했습니다.`);
        close();
      };

      box.querySelector('#eims-manual-stat-cancel').onclick=()=>close();
    },920);
  }

  function renderStats(){
    const h=document.getElementById('eims-vlog-stats');if(!h)return;
    const pe=document.getElementById('eims-vlog-stats-period');if(pe)pe.textContent=`합산 ${statsPeriodLabel()}`;
    const x=loadStats(),cats=['화재','구조','구급','훈련','대민지원','기타','시동점검'];
    const c=k=>k==='총 입력'?x.records.length:x.records.filter(r=>r.op===k).length;
    const z=[`<span data-stat="총 입력" style="font-weight:700;cursor:pointer;text-decoration:underline">총 입력 ${c('총 입력')}건</span>`];
    cats.forEach(k=>{const n=c(k);if(n)z.push(`<span data-stat="${k}" style="cursor:pointer;text-decoration:underline">${k} ${n}건</span>`)});
    h.innerHTML=z.join('<span style="opacity:.45;margin:0 6px">·</span>');h.querySelectorAll('[data-stat]').forEach(e=>e.onclick=()=>showStatsDetail(e.dataset.stat));
  }

  async function buildPanel() {
    if (await panelHiddenFor24h()) return;
    if (document.getElementById('eims-vlog-panel')) return;
    const p=document.createElement('div');
    p.id='eims-vlog-panel';
    p.style.cssText='position:fixed;right:18px;top:90px;width:310px;background:#16181d;color:#fff;z-index:2147483646;border:1px solid #444;border-radius:9px;box-shadow:0 8px 28px rgba(0,0,0,.35);font:13px/1.4 Arial,"Malgun Gothic",sans-serif;';
    p.innerHTML=`
      <div id="eims-vlog-head" style="padding:9px 10px;border-bottom:1px solid #3a3a3a;cursor:move;font-weight:700;user-select:none">
        <span>EIMS 차량운행일지 v47 <small id="eims-vlog-title-date" style="font-size:11px;font-weight:400;color:#cbd5e1;margin-left:5px"></small></span>
        <span style="float:right;display:flex;gap:5px">
          <div id="eims-vlog-min" role="button" title="최소화"
               style="width:25px;height:24px;line-height:22px;text-align:center;background:#2d3138;border:1px solid #555;border-radius:4px;cursor:pointer">—</div>
          <div id="eims-vlog-close" role="button" title="닫기"
               style="width:25px;height:24px;line-height:22px;text-align:center;background:#2d3138;border:1px solid #555;border-radius:4px;cursor:pointer">×</div>
        </span>
      </div>
      <div id="eims-vlog-body" style="padding:10px">
        <label>차량번호 <span id="eims-vlog-vehicle-name" style="font-size:12px;color:#d9f99d">(앙성20호)</span>
<select id="eims-vlog-vehicle"><option>998수5175</option><option>998수5124</option><option>998수5145</option><option>47모9366</option></select></label>
        <label>운행구분<select id="eims-vlog-op">${Object.keys(OP).map(x=>`<option${x==='시동점검'?' selected':''}>${x}</option>`).join('')}</select></label>
        <label>수동입력 시 목적지<input id="eims-vlog-dest" value="차고 앞" placeholder="선택 입력"></label>
        <label style="display:flex;gap:7px;align-items:center"><input id="eims-vlog-autosave" type="checkbox">입력 후 저장 버튼까지 클릭</label>
        <div id="eims-vlog-run" role="button" tabindex="0"
             style="width:100%;box-sizing:border-box;margin-top:9px;padding:10px 9px;background:#2563eb;color:#fff;
                    border:0;border-radius:6px;font-size:14px;font-weight:700;line-height:20px;text-align:center;
                    text-indent:0;letter-spacing:0;cursor:pointer">자동입력 실행</div>
        <div id="eims-vlog-status" style="margin-top:9px;min-height:38px;color:#d9f99d">어느 EIMS 화면에서든 실행할 수 있습니다.</div>
        <div style="margin-top:8px;padding:8px;background:#20242b;border:1px solid #3d424b;border-radius:6px">
          <div style="font-size:12px;color:#aab2bd;margin-bottom:4px;display:flex;align-items:center;justify-content:space-between;gap:6px">
            <span id="eims-vlog-stats-title" title="최근 24시간 운행내역에서 통계에 수동 반영" style="cursor:pointer;text-decoration:underline">오늘 차량운행일지 입력 통계</span>
            <span style="display:flex;gap:5px">
              <span id="eims-vlog-stats-graph" style="cursor:pointer;border:1px solid #555;border-radius:4px;padding:2px 6px;color:#ddd">그래프</span>
              <span id="eims-vlog-stats-reset" style="cursor:pointer;border:1px solid #555;border-radius:4px;padding:2px 6px">통계 초기화</span>
            </span>
          </div>
          <div id="eims-vlog-stats-period" style="font-size:10px;color:#8f99a8;margin-bottom:4px"></div>
          <div id="eims-vlog-stats" style="font-size:12px;color:#f3f4f6;line-height:1.6"></div>
        </div>
        <div id="eims-vlog-hide24" role="button" tabindex="0"
             style="margin-top:8px;padding:7px 8px;background:#2d3138;color:#ddd;border:1px solid #555;border-radius:5px;
                    text-align:center;font-size:12px;cursor:pointer">오늘 하루 그만보기</div>
      </div>`;
    document.body.appendChild(p);
    renderStats();
    {const d=new Date(),de=p.querySelector('#eims-vlog-title-date');if(de)de.textContent=`${d.getMonth()+1}월 ${d.getDate()}일`;
     const vs=p.querySelector('#eims-vlog-vehicle'),vn=p.querySelector('#eims-vlog-vehicle-name'),sync=()=>{if(vn)vn.textContent=`(${VEHICLES[vs.value]||''})`;};vs?.addEventListener('change',sync);sync();
     const periodEl=p.querySelector('#eims-vlog-stats-period');if(periodEl)periodEl.textContent=`합산 ${statsPeriodLabel()}`;
     p.querySelector('#eims-vlog-stats-title').onclick=()=>showManualStatsImport();
     p.querySelector('#eims-vlog-stats-graph').onclick=()=>showStatsGraph();
     p.querySelector('#eims-vlog-stats-reset').onclick=()=>{if(confirm('현재 근무 통계를 초기화할까요?')){saveStats(emptyStats());renderStats();}};}
    p.querySelectorAll('input[type="text"],input:not([type]),select').forEach(el=>{
      el.style.cssText='display:block;width:100%;box-sizing:border-box;margin:3px 0 8px;padding:6px;border:1px solid #666;border-radius:5px;background:#fff;color:#111;';
    });
    p.querySelector('#eims-vlog-run').onclick=run;
    p.querySelector('#eims-vlog-run').onkeydown=e=>{
      if(e.key==='Enter' || e.key===' '){ e.preventDefault(); run(); }
    };
    p.querySelector('#eims-vlog-close').onclick=()=>p.remove();
    p.querySelector('#eims-vlog-min').onclick=()=>{
      const b=p.querySelector('#eims-vlog-body');
      b.style.display=b.style.display==='none'?'block':'none';
    };
    // v40: 팝업이 최초 생성될 때 본문을 접어 최소화 상태로 표시한다.
    p.querySelector('#eims-vlog-body').style.display='none';
    p.querySelector('#eims-vlog-hide24').onclick=()=>{ hidePanelFor24h(p); };
    p.querySelector('#eims-vlog-hide24').onkeydown=e=>{
      if(e.key==='Enter' || e.key===' '){
        e.preventDefault();
        hidePanelFor24h(p);
      }
    };
    let dragging=false, ox=0, oy=0;
    const head=p.querySelector('#eims-vlog-head');
    head.addEventListener('mousedown',e=>{
      if (e.target.closest('#eims-vlog-min,#eims-vlog-close')) return;
      dragging=true; const r=p.getBoundingClientRect(); ox=e.clientX-r.left; oy=e.clientY-r.top;
    });
    document.addEventListener('mousemove',e=>{
      if(!dragging)return; p.style.left=(e.clientX-ox)+'px';p.style.top=(e.clientY-oy)+'px';p.style.right='auto';
    });
    document.addEventListener('mouseup',()=>dragging=false);
  }


  function operationGridRows() {
    return [...document.querySelectorAll('tr.grid_body_row')]
      .filter(tr => tr.querySelector('td[id*="mf_tcMain_contents_tab_103002001_body_gridView2_cell_"]'));
  }

  function operationRowSignature(tr) {
    if (!tr) return null;
    const get = col => (tr.querySelector(`td[col_id="${col}"]`)?.textContent || '').trim();
    return {
      date: get('opratDe'),
      begin: get('opratBeginDt'),
      end: get('opratEndDt'),
      op: get('opratSeCd'),
      etc: get('etcBusins'),
      destination: get('dstn'),
      distance: get('opratDstnc').replace(/,/g,'')
    };
  }

  function focusedOperationRow() {
    const rows = operationGridRows();
    return rows.find(tr =>
      tr.querySelector('td.focusedTr[id*="mf_tcMain_contents_tab_103002001_body_gridView2_cell_"]')
    ) || null;
  }

  function signatureStillExists(sig) {
    if (!sig) return false;
    return operationGridRows().some(tr => {
      const r = operationRowSignature(tr);
      return r &&
        r.date === sig.date &&
        r.begin === sig.begin &&
        r.end === sig.end &&
        r.op === sig.op &&
        r.etc === sig.etc &&
        r.destination === sig.destination &&
        r.distance === sig.distance;
    });
  }

  function removeMatchingStatBySignature(vehicle, sig) {
    const x = loadStats();
    for (let i = x.records.length - 1; i >= 0; i--) {
      const r = x.records[i];

      const opOk = !sig.op || r.op === sig.op;
      const vehicleOk = !vehicle || r.vehicle === vehicle;
      const etcOk = !sig.etc || !r.etc || r.etc === sig.etc;
      const dstOk = !sig.destination || !r.destination || r.destination === sig.destination;
      const distOk = !sig.distance || r.distance === '' || String(r.distance).replace(/,/g,'') === sig.distance;

      if (vehicleOk && opOk && etcOk && dstOk && distOk) {
        const removed = x.records.splice(i, 1)[0];
        saveStats(x);
        renderStats();
        return removed;
      }
    }
    return null;
  }

  // EIMS 삭제 버튼 + 우측 운행내역 gridView2 행 식별 기반 통계 연동
  let eimsDeletePending = null;

  document.addEventListener('click', e => {
    const btn = e.target.closest(`#${IDS.delete}`);
    if (!btn) return;

    const panel = document.getElementById('eims-vlog-panel');
    const vehicle = panel?.querySelector('#eims-vlog-vehicle')?.value || '';

    const targetRow = focusedOperationRow();
    const signature = operationRowSignature(targetRow);
    const rowsBefore = operationGridRows().length;

    // 삭제 대상 행을 식별하지 못한 경우 통계는 건드리지 않는다.
    if (!signature) {
      console.warn('[EIMS 차량운행일지] 삭제 대상 운행내역 행을 식별하지 못해 통계 차감을 보류합니다.');
      return;
    }

    eimsDeletePending = {
      vehicle,
      signature,
      rowsBefore,
      at: Date.now()
    };

    // EIMS 삭제 확인창 처리 후 실제 행이 사라지는지 최대 10초 확인.
    let tries = 0;
    const timer = setInterval(() => {
      tries++;

      if (!eimsDeletePending) {
        clearInterval(timer);
        return;
      }

      const rowsAfter = operationGridRows().length;
      const targetGone = !signatureStillExists(eimsDeletePending.signature);
      const rowCountReduced = rowsAfter < eimsDeletePending.rowsBefore;

      if (targetGone || rowCountReduced) {
        removeMatchingStatBySignature(
          eimsDeletePending.vehicle,
          eimsDeletePending.signature
        );
        eimsDeletePending = null;
        clearInterval(timer);
      } else if (tries >= 20) {
        // 삭제 취소 또는 실제 행 변화 없음 → 통계 유지
        eimsDeletePending = null;
        clearInterval(timer);
      }
    }, 500);
  }, true);

  buildPanel();
})();
